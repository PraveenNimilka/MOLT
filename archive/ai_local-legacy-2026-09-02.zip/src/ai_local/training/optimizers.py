from __future__ import annotations

from collections.abc import Iterable

import torch

from ai_local.core.config import ExperimentConfig


class ResidualSGD(torch.optim.Optimizer):
    """SGD with a same-dtype error-feedback buffer for rounded-away updates.

    This is a compact Kahan/error-feedback mechanism check, not a novel method.
    It trades one parameter-sized buffer for avoiding FP32 master weights.
    """

    def __init__(self, params: Iterable[torch.Tensor], lr: float, weight_decay: float = 0.0):
        if lr <= 0:
            raise ValueError("learning rate must be positive")
        if weight_decay < 0:
            raise ValueError("weight decay must be non-negative")
        super().__init__(params, {"lr": lr, "weight_decay": weight_decay})

    @torch.no_grad()
    def step(self, closure=None):
        loss = closure() if closure is not None else None
        for group in self.param_groups:
            lr = group["lr"]
            weight_decay = group["weight_decay"]
            for parameter in group["params"]:
                if parameter.grad is None:
                    continue
                gradient = parameter.grad
                if gradient.is_sparse:
                    raise RuntimeError("ResidualSGD does not support sparse gradients")
                state = self.state[parameter]
                if "residual" not in state:
                    state["residual"] = torch.zeros_like(parameter, memory_format=torch.preserve_format)
                residual = state["residual"]
                if weight_decay:
                    residual.add_(parameter, alpha=-lr * weight_decay)
                residual.add_(gradient, alpha=-lr)
                updated = parameter + residual
                residual.sub_(updated - parameter)
                parameter.copy_(updated)
        return loss


def build_optimizer(model: torch.nn.Module, cfg: ExperimentConfig) -> torch.optim.Optimizer:
    training = cfg.training
    if training.optimizer == "adamw":
        decay = [parameter for parameter in model.parameters() if parameter.requires_grad and parameter.ndim >= 2]
        no_decay = [parameter for parameter in model.parameters() if parameter.requires_grad and parameter.ndim < 2]
        return torch.optim.AdamW(
            [
                {"params": decay, "weight_decay": training.weight_decay},
                {"params": no_decay, "weight_decay": 0.0},
            ],
            lr=training.learning_rate,
            betas=(0.9, 0.95),
            fused=training.fused_optimizer,
            foreach=False if not training.fused_optimizer else None,
        )
    if training.optimizer == "sgd":
        return torch.optim.SGD(
            model.parameters(), lr=training.learning_rate, weight_decay=training.weight_decay
        )
    return ResidualSGD(
        model.parameters(), lr=training.learning_rate, weight_decay=training.weight_decay
    )
