"""Training model and engine."""
