from __future__ import annotations

import json
import math
import random
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import torch

from ai_local.core.config import ExperimentConfig
from ai_local.core.io import atomic_json, sha256_file
from ai_local.data.bytes import ByteBatcher
from ai_local.experiments.store import RunStore, resolve_checkpoint, resolve_run
from ai_local.measurement.telemetry import Telemetry
from ai_local.training.model import ByteTransformer, model_stats, resolve_dtype
from ai_local.training.optimizers import build_optimizer


def _manifest(cfg: ExperimentConfig) -> dict[str, Any]:
    path = Path(cfg.data.prepared_dir) / "manifest.json"
    if not path.is_file():
        raise FileNotFoundError(f"prepared manifest missing: {path}; run ai-local prepare first")
    value = json.loads(path.read_text(encoding="utf-8"))
    for split in ("train", "validation"):
        item = value[split]
        if sha256_file(item["path"]) != item["sha256"]:
            raise ValueError(f"{split} data hash mismatch")
        if item.get("loss_mask_path") and sha256_file(item["loss_mask_path"]) != item["loss_mask_sha256"]:
            raise ValueError(f"{split} loss mask hash mismatch")
    tokenizer = value.get("tokenizer")
    if tokenizer and sha256_file(tokenizer["path"]) != tokenizer["sha256"]:
        raise ValueError("tokenizer hash mismatch")
    return value


def _device(cfg: ExperimentConfig) -> torch.device:
    if cfg.training.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable; no CPU fallback is permitted")
    return torch.device(cfg.training.device)


def _seed_everything(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _autocast(cfg: ExperimentConfig, device: torch.device):
    enabled = cfg.training.precision != "float32"
    return torch.autocast(device_type=device.type, dtype=resolve_dtype(cfg.training.precision), enabled=enabled)


@torch.no_grad()
def evaluate(
    model: ByteTransformer,
    cfg: ExperimentConfig,
    validation_path: str,
    device: torch.device,
    storage_dtype: str = "uint8",
    loss_mask_path: str | None = None,
) -> dict[str, float]:
    model.eval()
    batcher = ByteBatcher(
        validation_path,
        cfg.data.context_length,
        seed=0,
        device=device,
        storage_dtype=storage_dtype,
        sampling="sequential",
            loss_mask_path=loss_mask_path,
            packing=cfg.data.packing,
    )
    total_nll = 0.0
    total_tokens = 0
    for _ in range(cfg.training.eval_batches):
        x, y = batcher.batch(cfg.training.micro_batch_size)
        with _autocast(cfg, device):
            _, loss = model(x, y)
        assert loss is not None
        count = int((y != -100).sum())
        if count == 0:
            raise ValueError("evaluation batch contains no supervised targets")
        total_nll += float(loss.detach()) * count
        total_tokens += count
    model.train()
    nll = total_nll / total_tokens
    metrics = {
        "validation_nll": nll,
        "validation_perplexity": math.exp(min(nll, 80.0)),
        "validation_tokens": total_tokens,
    }
    unit = "token" if cfg.data.kind.startswith("text_bpe") else "byte"
    metrics[f"validation_bits_per_{unit}"] = nll / math.log(2.0)
    return metrics


def _scheduled_learning_rate(cfg: ExperimentConfig, completed_steps: int) -> float:
    training = cfg.training
    update = completed_steps + 1
    if training.warmup_steps and update <= training.warmup_steps:
        return training.learning_rate * update / training.warmup_steps
    decay_steps = training.max_steps - training.warmup_steps
    if decay_steps <= 0:
        return training.learning_rate
    progress = min(1.0, max(0.0, (update - training.warmup_steps) / decay_steps))
    cosine = 0.5 * (1.0 + math.cos(math.pi * progress))
    multiplier = training.min_learning_rate_ratio + (1.0 - training.min_learning_rate_ratio) * cosine
    return training.learning_rate * multiplier


def _checkpoint_state(
    cfg: ExperimentConfig,
    model: ByteTransformer,
    optimizer: torch.optim.Optimizer,
    scaler: torch.amp.GradScaler,
    batcher: ByteBatcher,
    step: int,
    tokens: int,
) -> dict[str, Any]:
    state: dict[str, Any] = {
        "schema_version": 1,
        "config": cfg.to_dict(),
        "model": model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "scaler": scaler.state_dict(),
        "batcher": batcher.state_dict(),
        "step": step,
        "tokens": tokens,
        "torch_rng": torch.get_rng_state(),
    }
    if torch.cuda.is_available():
        state["cuda_rng"] = torch.cuda.get_rng_state_all()
    return state


def train(cfg: ExperimentConfig, resume_run: str | Path | None = None) -> Path:
    cfg.validate()
    manifest = _manifest(cfg)
    device = _device(cfg)
    _seed_everything(cfg.seed)
    store = RunStore(cfg, existing=resume_run)
    if resume_run is not None:
        status_path = store.path / "status.json"
        previous = json.loads(status_path.read_text(encoding="utf-8")) if status_path.is_file() else {}
        if previous.get("state") == "completed":
            raise ValueError("completed runs are immutable and cannot be resumed")
        resolve_checkpoint(store.path)
    store.environment()
    store.status("running")
    store.event("run_started", resumed=resume_run is not None)
    telemetry = Telemetry(cfg.telemetry_interval_seconds, enable_gpu=device.type == "cuda")
    telemetry.start()
    start = time.perf_counter()
    model: ByteTransformer | None = None
    try:
        if device.type == "cuda":
            torch.cuda.reset_peak_memory_stats()
        init_start = time.perf_counter()
        model = ByteTransformer(cfg, device)
        stats = model_stats(model)
        initialization_seconds = time.perf_counter() - init_start
        store.event("model_initialized", seconds=initialization_seconds, **asdict(stats))
        if cfg.training.initialize_from_run:
            source_run = resolve_run(cfg.training.initialize_from_run)
            source_checkpoint = torch.load(
                resolve_checkpoint(source_run), map_location=device, weights_only=False
            )
            model.load_state_dict(source_checkpoint["model"], strict=True)
            store.event(
                "model_initialized_from_checkpoint",
                source_run=source_run.name,
                source_step=int(source_checkpoint["step"]),
                source_tokens=int(source_checkpoint["tokens"]),
            )
        optimizer = build_optimizer(model, cfg)
        scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda" and cfg.training.precision == "float16")
        storage_dtype = str(manifest.get("storage_dtype", "uint8"))
        batcher = ByteBatcher(
            manifest["train"]["path"],
            cfg.data.context_length,
            cfg.seed,
            device,
            storage_dtype=storage_dtype,
            sampling=cfg.data.sampling,
            loss_mask_path=manifest["train"].get("loss_mask_path"),
            packing=cfg.data.packing,
        )
        step = 0
        tokens = 0
        if resume_run is not None:
            checkpoint = torch.load(resolve_checkpoint(store.path), map_location=device, weights_only=False)
            if checkpoint["config"] != cfg.to_dict():
                raise ValueError("resolved config differs from checkpoint config")
            model.load_state_dict(checkpoint["model"])
            optimizer.load_state_dict(checkpoint["optimizer"])
            scaler.load_state_dict(checkpoint["scaler"])
            batcher.load_state_dict(checkpoint["batcher"])
            step, tokens = int(checkpoint["step"]), int(checkpoint["tokens"])
            torch.set_rng_state(checkpoint["torch_rng"])
            if device.type == "cuda" and "cuda_rng" in checkpoint:
                torch.cuda.set_rng_state_all(checkpoint["cuda_rng"])
            store.event("checkpoint_loaded", step=step, tokens=tokens)

        evaluation_start = time.perf_counter()
        initial = evaluate(
            model,
            cfg,
            manifest["validation"]["path"],
            device,
            storage_dtype,
            manifest["validation"].get("loss_mask_path"),
        )
        evaluation_seconds = time.perf_counter() - evaluation_start
        training_step_seconds = 0.0
        data_enqueue_seconds = 0.0
        checkpoint_seconds = 0.0
        store.event("evaluation", step=step, tokens=tokens, **initial)
        evaluations = [{"step": step, "tokens": tokens, "elapsed_seconds": time.perf_counter() - start, **initial}]
        model.train()
        timeout = False
        while step < cfg.training.max_steps:
            if cfg.training.max_seconds is not None and time.perf_counter() - start >= cfg.training.max_seconds:
                timeout = True
                break
            current_learning_rate = _scheduled_learning_rate(cfg, step)
            for group in optimizer.param_groups:
                group["lr"] = current_learning_rate
            optimizer.zero_grad(set_to_none=True)
            step_loss = 0.0
            step_tokens = 0
            step_supervised_tokens = 0
            step_data_seconds = 0.0
            step_start = time.perf_counter()
            for _ in range(cfg.training.gradient_accumulation):
                data_start = time.perf_counter()
                x, y = batcher.batch(cfg.training.micro_batch_size)
                step_data_seconds += time.perf_counter() - data_start
                with _autocast(cfg, device):
                    _, loss = model(x, y)
                    assert loss is not None
                    scaled_loss = loss / cfg.training.gradient_accumulation
                if not torch.isfinite(loss):
                    raise FloatingPointError(f"non-finite loss at step {step + 1}: {float(loss)}")
                scaler.scale(scaled_loss).backward()
                step_loss += float(loss.detach())
                step_tokens += y.numel()
                step_supervised_tokens += int((y != -100).sum())
            scaler.unscale_(optimizer)
            grad_norm = float(torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.training.gradient_clip))
            scaler.step(optimizer)
            scaler.update()
            if device.type == "cuda":
                torch.cuda.synchronize()
            step += 1
            tokens += step_tokens
            elapsed_step = time.perf_counter() - step_start
            training_step_seconds += elapsed_step
            data_enqueue_seconds += step_data_seconds
            store.event(
                "train_step",
                step=step,
                tokens=tokens,
                supervised_tokens=step_supervised_tokens,
                loss=step_loss / cfg.training.gradient_accumulation,
                gradient_norm=grad_norm,
                learning_rate=current_learning_rate,
                seconds=elapsed_step,
                data_enqueue_seconds=step_data_seconds,
                tokens_per_second=step_tokens / elapsed_step,
            )
            if cfg.training.eval_interval and (step % cfg.training.eval_interval == 0 or step == cfg.training.max_steps):
                evaluation_start = time.perf_counter()
                metrics = evaluate(
                    model,
                    cfg,
                    manifest["validation"]["path"],
                    device,
                    storage_dtype,
                    manifest["validation"].get("loss_mask_path"),
                )
                evaluation_seconds += time.perf_counter() - evaluation_start
                record = {"step": step, "tokens": tokens, "elapsed_seconds": time.perf_counter() - start, **metrics}
                evaluations.append(record)
                store.event("evaluation", **record)
            if cfg.training.checkpoint_interval and step % cfg.training.checkpoint_interval == 0:
                save_start = time.perf_counter()
                path = store.save_checkpoint(_checkpoint_state(cfg, model, optimizer, scaler, batcher, step, tokens))
                save_seconds = time.perf_counter() - save_start
                checkpoint_seconds += save_seconds
                store.event("checkpoint_saved", step=step, seconds=save_seconds, bytes=path.stat().st_size)

        if cfg.training.save_final_checkpoint:
            save_start = time.perf_counter()
            path = store.save_checkpoint(_checkpoint_state(cfg, model, optimizer, scaler, batcher, step, tokens))
            save_seconds = time.perf_counter() - save_start
            checkpoint_seconds += save_seconds
            store.event("checkpoint_saved", step=step, final=True, seconds=save_seconds, bytes=path.stat().st_size)
        telemetry_summary = telemetry.stop()
        total_seconds = time.perf_counter() - start
        summary = {
            "schema_version": 1,
            "run_id": store.path.name,
            "state": "time_limit" if timeout else "completed",
            "steps": step,
            "tokens": tokens,
            "total_seconds": total_seconds,
            "tokens_per_second_end_to_end": tokens / total_seconds if total_seconds else None,
            "model": asdict(stats),
            "evaluations": evaluations,
            "phases": {
                "model_initialization_seconds": initialization_seconds,
                "training_steps_seconds": training_step_seconds,
                "data_enqueue_seconds": data_enqueue_seconds,
                "evaluation_seconds": evaluation_seconds,
                "checkpoint_seconds": checkpoint_seconds,
            },
            "telemetry": {k: v for k, v in telemetry_summary.items() if k != "samples"},
            "cuda_peak_allocated_bytes": torch.cuda.max_memory_allocated() if device.type == "cuda" else None,
            "cuda_peak_reserved_bytes": torch.cuda.max_memory_reserved() if device.type == "cuda" else None,
        }
        atomic_json(store.path / "telemetry.samples.json", telemetry_summary)
        store.summary(summary)
        store.status(summary["state"], step=step, tokens=tokens)
        store.event("run_finished", state=summary["state"], seconds=total_seconds)
        return store.path
    except BaseException as exc:
        telemetry_summary = telemetry.stop()
        atomic_json(store.path / "telemetry.samples.json", telemetry_summary)
        store.status("failed", error_type=type(exc).__name__, error=str(exc))
        store.event("run_failed", error_type=type(exc).__name__, error=str(exc))
        raise
