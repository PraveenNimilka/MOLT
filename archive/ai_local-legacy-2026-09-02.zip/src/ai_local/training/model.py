from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.attention import SDPBackend, sdpa_kernel
from torch.utils.checkpoint import checkpoint

from ai_local.core.config import ExperimentConfig


def resolve_dtype(name: str) -> torch.dtype:
    return {"float32": torch.float32, "float16": torch.float16, "bfloat16": torch.bfloat16}[name]


class TransformerBlock(nn.Module):
    def __init__(self, width: int, heads: int, mlp_ratio: int, *, device: torch.device, dtype: torch.dtype, attention_backend: str):
        super().__init__()
        self.heads = heads
        self.head_dim = width // heads
        self.attention_backend = attention_backend
        self.ln1 = nn.LayerNorm(width, device=device, dtype=dtype)
        self.qkv = nn.Linear(width, 3 * width, device=device, dtype=dtype)
        self.proj = nn.Linear(width, width, device=device, dtype=dtype)
        self.ln2 = nn.LayerNorm(width, device=device, dtype=dtype)
        hidden = width * mlp_ratio
        self.fc1 = nn.Linear(width, hidden, device=device, dtype=dtype)
        self.fc2 = nn.Linear(hidden, width, device=device, dtype=dtype)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch, length, width = x.shape
        qkv = self.qkv(self.ln1(x)).view(batch, length, 3, self.heads, self.head_dim)
        q, k, v = qkv.unbind(dim=2)
        q, k, v = (item.transpose(1, 2) for item in (q, k, v))
        if self.attention_backend == "auto":
            attention = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        else:
            backend = {
                "flash": SDPBackend.FLASH_ATTENTION,
                "efficient": SDPBackend.EFFICIENT_ATTENTION,
                "math": SDPBackend.MATH,
            }[self.attention_backend]
            with sdpa_kernel(backend):
                attention = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        x = x + self.proj(attention.transpose(1, 2).contiguous().view(batch, length, width))
        x = x + self.fc2(F.gelu(self.fc1(self.ln2(x)), approximate="tanh"))
        return x


class ByteTransformer(nn.Module):
    def __init__(self, cfg: ExperimentConfig, device: torch.device):
        super().__init__()
        model = cfg.model
        data = cfg.data
        context_capacity = model.max_context_length or data.context_length
        dtype = resolve_dtype(model.parameter_dtype)
        self.activation_checkpointing = model.activation_checkpointing
        self.activation_dtype = (
            None if model.activation_dtype == "parameter" else resolve_dtype(model.activation_dtype)
        )
        self.token_embedding = nn.Embedding(data.vocab_size, model.d_model, device=device, dtype=dtype)
        self.position_embedding = nn.Embedding(context_capacity, model.d_model, device=device, dtype=dtype)
        self.blocks = nn.ModuleList(
            [
                TransformerBlock(
                    model.d_model,
                    model.n_heads,
                    model.mlp_ratio,
                    device=device,
                    dtype=dtype,
                    attention_backend=model.attention_backend,
                )
                for _ in range(model.n_layers)
            ]
        )
        self.final_norm = nn.LayerNorm(model.d_model, device=device, dtype=dtype)
        self.output = nn.Linear(model.d_model, data.vocab_size, bias=False, device=device, dtype=dtype)
        self.output.weight = self.token_embedding.weight
        self.register_buffer("positions", torch.arange(context_capacity, device=device), persistent=False)
        self.apply(self._init_weights)

    @staticmethod
    def _init_weights(module: nn.Module) -> None:
        if isinstance(module, (nn.Linear, nn.Embedding)):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if isinstance(module, nn.Linear) and module.bias is not None:
                nn.init.zeros_(module.bias)

    def forward(
        self,
        tokens: torch.Tensor,
        targets: torch.Tensor | None = None,
        *,
        position_offset: int = 0,
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        length = tokens.shape[1]
        if position_offset < 0 or position_offset + length > self.positions.numel():
            raise ValueError("requested positions exceed model context capacity")
        positions = self.positions[position_offset : position_offset + length]
        x = self.token_embedding(tokens) + self.position_embedding(positions)
        # PyTorch autocast does not cast embedding outputs. Keeping the residual
        # stream in the configured compute dtype avoids retaining FP32 block
        # activations while preserving FP32 parameters and optimizer state.
        if self.activation_dtype is not None:
            x = x.to(self.activation_dtype)
        for block in self.blocks:
            if self.activation_checkpointing and self.training:
                # Blocks contain no stochastic operations, so saving/restoring
                # RNG state adds overhead without affecting their recomputation.
                x = checkpoint(block, x, use_reentrant=False, preserve_rng_state=False)
            else:
                x = block(x)
        logits = self.output(self.final_norm(x))
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.float().reshape(-1, logits.shape[-1]), targets.reshape(-1))
        return logits, loss


@dataclass(frozen=True)
class ModelStats:
    total_parameters: int
    trainable_parameters: int
    parameter_bytes: int
    estimated_training_flops_per_token: int


def model_stats(model: nn.Module) -> ModelStats:
    parameters = list(model.parameters())
    total = sum(item.numel() for item in parameters)
    trainable = sum(item.numel() for item in parameters if item.requires_grad)
    size = sum(item.numel() * item.element_size() for item in parameters)
    return ModelStats(total, trainable, size, 6 * total)
