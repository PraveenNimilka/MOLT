from __future__ import annotations

import argparse
import json
import math
import os
import platform
import shutil
import sys
import time
from pathlib import Path
from typing import Any

import psutil
import torch

from ai_local.core.config import ConfigError, ExperimentConfig
from ai_local.benchmarks.saturation import saturation_search
from ai_local.benchmarks.telescoping import telescoping_probe
from ai_local.benchmarks.utilization import utilization_probe
from ai_local.benchmarks.controller import controller_probe
from ai_local.data.bytes import prepare
from ai_local.evaluation.runs import compare_runs, evaluate_run, generate_run
from ai_local.evaluation.frontier import build_time_energy_frontier
from ai_local.experiments.store import resolve_run
from ai_local.training.engine import train


def _print(value: Any) -> None:
    print(json.dumps(value, indent=2, sort_keys=True))


def inspect_system() -> dict[str, Any]:
    memory = psutil.virtual_memory()
    disk = shutil.disk_usage(Path.cwd())
    result: dict[str, Any] = {
        "platform": platform.platform(),
        "python": sys.version,
        "torch": torch.__version__,
        "torch_cuda_runtime": torch.version.cuda,
        "cpu_logical_count": psutil.cpu_count(logical=True),
        "ram_total_bytes": memory.total,
        "ram_available_bytes": memory.available,
        "workspace": str(Path.cwd()),
        "workspace_disk_free_bytes": disk.free,
        "cuda_available": torch.cuda.is_available(),
    }
    if torch.cuda.is_available():
        free, total = torch.cuda.mem_get_info()
        result["gpu"] = {
            "name": torch.cuda.get_device_name(0),
            "capability": torch.cuda.get_device_capability(0),
            "free_vram_bytes": free,
            "total_vram_bytes": total,
            "bf16_supported": torch.cuda.is_bf16_supported(),
        }
    return result


def benchmark_matmul(seconds: float = 3.0, size: int = 4096) -> dict[str, Any]:
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA benchmark requested but CUDA is unavailable")
    device = torch.device("cuda")
    left = torch.randn((size, size), device=device, dtype=torch.bfloat16)
    right = torch.randn((size, size), device=device, dtype=torch.bfloat16)
    for _ in range(3):
        torch.mm(left, right)
    torch.cuda.synchronize()
    start = time.perf_counter()
    iterations = 0
    while time.perf_counter() - start < seconds:
        for _ in range(10):
            torch.mm(left, right)
        iterations += 10
        torch.cuda.synchronize()
    elapsed = time.perf_counter() - start
    flops = iterations * 2 * size**3
    return {
        "dtype": "bfloat16",
        "matrix_size": size,
        "iterations": iterations,
        "seconds": elapsed,
        "achieved_tflops": flops / elapsed / 1e12,
        "note": "GEMM-only upper bound; not end-to-end training throughput",
    }


def feasibility(parameters: int, seconds: float, tflops: float, tokens_per_parameter: float) -> dict[str, Any]:
    available_flops = seconds * tflops * 1e12
    maximum_tokens = available_flops / (6 * parameters)
    target_tokens = tokens_per_parameter * parameters
    return {
        "parameters": parameters,
        "seconds": seconds,
        "assumed_sustained_tflops": tflops,
        "approximate_flops_per_training_token": 6 * parameters,
        "optimistic_maximum_tokens": maximum_tokens,
        "target_tokens": target_tokens,
        "fraction_of_target": maximum_tokens / target_tokens,
        "required_sustained_tflops": 6 * parameters * target_tokens / seconds / 1e12,
        "warning": "This arithmetic ignores attention, data, evaluation, checkpointing, and inefficiency; it is optimistic.",
    }


def _positive_csv(value: str) -> list[int]:
    try:
        values = [int(item.strip()) for item in value.split(",") if item.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("expected comma-separated integers") from exc
    if not values or min(values) <= 0:
        raise argparse.ArgumentTypeError("values must be positive")
    return values


def _probability_csv(value: str) -> list[float]:
    try:
        values = [float(item.strip()) for item in value.split(",") if item.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("expected comma-separated probabilities") from exc
    if not values or any(item <= 0 or item > 1 for item in values):
        raise argparse.ArgumentTypeError("probabilities must be in (0, 1]")
    return values


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ai-local", description="Local AI training research platform")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("inspect", help="Inspect local hardware and runtime")
    prep = sub.add_parser("prepare", help="Prepare deterministic data")
    prep.add_argument("--config", required=True)
    training = sub.add_parser("train", help="Start a new run")
    training.add_argument("--config", required=True)
    resume = sub.add_parser("resume", help="Resume a checkpointed run")
    resume.add_argument("--run", required=True)
    evaluation = sub.add_parser("evaluate", help="Evaluate a checkpointed run")
    evaluation.add_argument("--run", required=True)
    generation = sub.add_parser("generate", help="Generate text from a checkpointed byte model")
    generation.add_argument("--run", required=True)
    generation.add_argument("--prompt", required=True)
    generation.add_argument(
        "--max-new-tokens",
        "--max-new-bytes",
        dest="max_new_bytes",
        type=int,
        default=128,
        help="Number of tokens to generate (bytes for legacy byte models)",
    )
    generation.add_argument("--temperature", type=float, default=0.8)
    generation.add_argument("--top-k", type=int, default=40)
    generation.add_argument("--seed", type=int, default=1337)
    benchmark = sub.add_parser("benchmark", help="Benchmark CUDA BF16 matrix multiplication")
    benchmark.add_argument("--seconds", type=float, default=3.0)
    benchmark.add_argument("--size", type=int, default=4096)
    tune = sub.add_parser("tune", help="Search CUDA workload shapes for sustained training throughput")
    tune.add_argument("--config", required=True)
    tune.add_argument("--contexts", type=_positive_csv, default=[8, 16, 32, 64])
    tune.add_argument("--micro-batches", type=_positive_csv, default=[1])
    tune.add_argument("--warmup-steps", type=int, default=1)
    tune.add_argument("--steps", type=int, default=3)
    tune.add_argument("--minimum-headroom-mib", type=int, default=512)
    utilization = sub.add_parser(
        "utilization-probe",
        help="Sweep microbatch/accumulation at a fixed effective token batch with NVML energy",
    )
    utilization.add_argument("--config", required=True)
    utilization.add_argument("--micro-batches", type=_positive_csv, required=True)
    utilization.add_argument("--warmup-steps", type=int, default=3)
    utilization.add_argument("--steps", type=int, default=20)
    utilization.add_argument("--precision", choices=("float32", "bfloat16", "float16"))
    utilization.add_argument("--packing", choices=("indexed", "contiguous"))
    utilization.add_argument(
        "--attention-backend", choices=("auto", "flash", "efficient", "math")
    )
    utilization.add_argument("--fused-optimizer", type=int, choices=(0, 1))
    controller = sub.add_parser(
        "controller-probe", help="Run the experimental live time-energy controller kill test"
    )
    controller.add_argument("--config", required=True)
    controller.add_argument("--blocks", type=int, default=8)
    controller.add_argument("--steps-per-block", type=int, default=10)
    telescope = sub.add_parser(
        "research-telescope",
        help="Probe cost and gradient variance of the experimental telescoping-context estimator",
    )
    telescope.add_argument("--config", required=True)
    telescope.add_argument("--levels", type=_positive_csv, required=True)
    telescope.add_argument("--probabilities", type=_probability_csv, required=True)
    telescope.add_argument("--target-tokens", type=int, required=True)
    telescope.add_argument("--micro-batch-size", type=int, default=2)
    telescope.add_argument("--samples", type=int, default=16)
    compare = sub.add_parser("compare", help="Compare two completed runs")
    compare.add_argument("baseline")
    compare.add_argument("candidate")
    frontier = sub.add_parser(
        "frontier", help="Build an end-to-end time/energy-to-validation-NLL Pareto frontier"
    )
    frontier.add_argument("baseline")
    frontier.add_argument("candidates", nargs="*")
    frontier.add_argument("--quality-tolerance", type=float, default=0.01)
    report = sub.add_parser("report", help="Print a run summary")
    report.add_argument("--run", required=True)
    bound = sub.add_parser("feasibility", help="Calculate an optimistic training compute bound")
    bound.add_argument("--parameters", type=int, default=1_000_000_000)
    bound.add_argument("--seconds", type=float, default=600.0)
    bound.add_argument("--tflops", type=float, required=True)
    bound.add_argument("--tokens-per-parameter", type=float, default=20.0)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "inspect":
            _print(inspect_system())
        elif args.command == "prepare":
            _print(prepare(ExperimentConfig.load(args.config)))
        elif args.command == "train":
            path = train(ExperimentConfig.load(args.config))
            _print({"run_id": path.name, "path": str(path)})
        elif args.command == "resume":
            path = resolve_run(args.run)
            cfg = ExperimentConfig.from_dict(json.loads((path / "spec.resolved.json").read_text(encoding="utf-8")))
            result = train(cfg, resume_run=path)
            _print({"run_id": result.name, "path": str(result)})
        elif args.command == "evaluate":
            _print(evaluate_run(args.run))
        elif args.command == "generate":
            _print(
                generate_run(
                    args.run,
                    args.prompt,
                    max_new_bytes=args.max_new_bytes,
                    temperature=args.temperature,
                    top_k=args.top_k,
                    seed=args.seed,
                )
            )
        elif args.command == "benchmark":
            _print(benchmark_matmul(args.seconds, args.size))
        elif args.command == "tune":
            _print(
                saturation_search(
                    ExperimentConfig.load(args.config),
                    args.contexts,
                    args.micro_batches,
                    warmup_steps=args.warmup_steps,
                    measured_steps=args.steps,
                    minimum_headroom_mib=args.minimum_headroom_mib,
                )
            )
        elif args.command == "research-telescope":
            _print(
                telescoping_probe(
                    ExperimentConfig.load(args.config),
                    levels=tuple(args.levels),
                    probabilities=tuple(args.probabilities),
                    target_tokens=args.target_tokens,
                    micro_batch_size=args.micro_batch_size,
                    samples=args.samples,
                )
            )
        elif args.command == "utilization-probe":
            _print(
                utilization_probe(
                    ExperimentConfig.load(args.config),
                    args.micro_batches,
                    warmup_steps=args.warmup_steps,
                    measured_steps=args.steps,
                    precision=args.precision,
                    packing=args.packing,
                    attention_backend=args.attention_backend,
                    fused_optimizer=(
                        None if args.fused_optimizer is None else bool(args.fused_optimizer)
                    ),
                )
            )
        elif args.command == "controller-probe":
            _print(
                controller_probe(
                    ExperimentConfig.load(args.config),
                    blocks=args.blocks,
                    steps_per_block=args.steps_per_block,
                )
            )
        elif args.command == "compare":
            _print(compare_runs(args.baseline, args.candidate))
        elif args.command == "frontier":
            _print(
                build_time_energy_frontier(
                    args.baseline,
                    args.candidates,
                    quality_tolerance=args.quality_tolerance,
                )
            )
        elif args.command == "report":
            path = resolve_run(args.run)
            _print(json.loads((path / "metrics.summary.json").read_text(encoding="utf-8")))
        elif args.command == "feasibility":
            _print(feasibility(args.parameters, args.seconds, args.tflops, args.tokens_per_parameter))
        return 0
    except (ConfigError, FileNotFoundError, ValueError, RuntimeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
