"""Run evaluation and comparison."""
