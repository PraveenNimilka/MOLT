from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from ai_local.core.config import ExperimentConfig
from ai_local.core.io import atomic_json
from ai_local.experiments.store import resolve_run


def interpolate_nll_crossing(
    evaluations: list[dict[str, Any]], target_nll: float
) -> dict[str, float] | None:
    for index, current in enumerate(evaluations):
        if float(current["validation_nll"]) <= target_nll:
            if index == 0:
                return {
                    "seconds": float(current["elapsed_seconds"]),
                    "tokens": float(current["tokens"]),
                }
            previous = evaluations[index - 1]
            high = float(previous["validation_nll"])
            low = float(current["validation_nll"])
            fraction = 1.0 if high == low else (high - target_nll) / (high - low)
            fraction = min(1.0, max(0.0, fraction))
            return {
                "seconds": float(previous["elapsed_seconds"])
                + fraction * (float(current["elapsed_seconds"]) - float(previous["elapsed_seconds"])),
                "tokens": float(previous["tokens"])
                + fraction * (float(current["tokens"]) - float(previous["tokens"])),
            }
    return None


def integrate_sample_field_until(
    samples: list[dict[str, Any]], elapsed_seconds: float, field: str
) -> float | None:
    usable = [item for item in samples if item.get(field) is not None]
    if len(usable) < 2:
        return None
    origin = float(usable[0]["monotonic_seconds"])
    cutoff = origin + elapsed_seconds
    total = 0.0
    for left, right in zip(usable, usable[1:]):
        left_time = float(left["monotonic_seconds"])
        right_time = float(right["monotonic_seconds"])
        if left_time >= cutoff:
            break
        segment_end = min(right_time, cutoff)
        if segment_end <= left_time:
            continue
        left_value = float(left[field])
        right_value = float(right[field])
        span = right_time - left_time
        end_value = (
            left_value
            if span == 0
            else left_value + (right_value - left_value) * (segment_end - left_time) / span
        )
        total += (segment_end - left_time) * (left_value + end_value) / 2.0
        if right_time >= cutoff:
            break
    return total


def _semantic_signature(cfg: ExperimentConfig) -> dict[str, Any]:
    return {
        "seed": cfg.seed,
        "data": {
            "prepared_dir": cfg.data.prepared_dir,
            "context_length": cfg.data.context_length,
            "vocab_size": cfg.data.vocab_size,
            "sampling": cfg.data.sampling,
        },
        "model": {
            "n_layers": cfg.model.n_layers,
            "d_model": cfg.model.d_model,
            "n_heads": cfg.model.n_heads,
            "mlp_ratio": cfg.model.mlp_ratio,
            "parameter_dtype": cfg.model.parameter_dtype,
            "max_context_length": cfg.model.max_context_length,
        },
        "optimizer": {
            "name": cfg.training.optimizer,
            "learning_rate": cfg.training.learning_rate,
            "weight_decay": cfg.training.weight_decay,
            "gradient_clip": cfg.training.gradient_clip,
            "warmup_steps": cfg.training.warmup_steps,
            "min_learning_rate_ratio": cfg.training.min_learning_rate_ratio,
            "max_steps": cfg.training.max_steps,
            "effective_tokens_per_update": (
                cfg.data.context_length
                * cfg.training.micro_batch_size
                * cfg.training.gradient_accumulation
            ),
        },
        "validation": {
            "eval_interval": cfg.training.eval_interval,
            "eval_batches": cfg.training.eval_batches,
        },
    }


def analyze_run_to_target(
    run: str | Path,
    *,
    target_nll: float,
    reference_signature: dict[str, Any],
    expected_tokens: int,
) -> dict[str, Any]:
    path = resolve_run(run)
    summary = json.loads((path / "metrics.summary.json").read_text(encoding="utf-8"))
    telemetry = json.loads((path / "telemetry.samples.json").read_text(encoding="utf-8"))
    cfg = ExperimentConfig.from_dict(
        json.loads((path / "spec.resolved.json").read_text(encoding="utf-8"))
    )
    crossing = interpolate_nll_crossing(summary["evaluations"], target_nll)
    samples = telemetry.get("samples", [])
    energy = None
    mean_utilization = None
    mean_power = None
    if crossing is not None:
        seconds = float(crossing["seconds"])
        energy = integrate_sample_field_until(samples, seconds, "gpu_power_watts")
        utilization_area = integrate_sample_field_until(samples, seconds, "gpu_utilization_percent")
        if utilization_area is not None and seconds > 0:
            mean_utilization = utilization_area / seconds
        if energy is not None and seconds > 0:
            mean_power = energy / seconds
    target_samples = []
    if crossing is not None and samples:
        origin = float(samples[0]["monotonic_seconds"])
        cutoff = origin + float(crossing["seconds"])
        target_samples = [item for item in samples if float(item["monotonic_seconds"]) <= cutoff]

    def observed(field: str) -> list[float]:
        return [float(item[field]) for item in target_samples if item.get(field) is not None]

    limits = observed("gpu_enforced_power_limit_watts")
    clocks = observed("gpu_graphics_clock_mhz")
    temperatures = observed("gpu_temperature_c")
    final_nll = float(summary["evaluations"][-1]["validation_nll"])
    compatible = _semantic_signature(cfg) == reference_signature
    reliable = summary["state"] == "completed" and int(summary["tokens"]) == expected_tokens
    eligible = compatible and reliable and crossing is not None and final_nll <= target_nll
    return {
        "run_id": path.name,
        "path": str(path),
        "eligible": eligible,
        "compatible_semantics": compatible,
        "reliable_exact_budget": reliable,
        "target_reached": crossing is not None,
        "target_nll": target_nll,
        "time_to_target_seconds": crossing["seconds"] if crossing else None,
        "tokens_to_target": crossing["tokens"] if crossing else None,
        "gpu_board_energy_to_target_joules": energy,
        "mean_gpu_power_to_target_watts": mean_power,
        "mean_gpu_utilization_to_target_percent": mean_utilization,
        "minimum_gpu_enforced_power_limit_to_target_watts": min(limits) if limits else None,
        "maximum_gpu_enforced_power_limit_to_target_watts": max(limits) if limits else None,
        "minimum_gpu_graphics_clock_to_target_mhz": min(clocks) if clocks else None,
        "maximum_gpu_graphics_clock_to_target_mhz": max(clocks) if clocks else None,
        "peak_gpu_temperature_to_target_c": max(temperatures) if temperatures else None,
        "final_validation_nll": final_nll,
        "total_seconds": summary["total_seconds"],
        "total_gpu_board_energy_joules": summary["telemetry"].get("gpu_board_energy_joules"),
        "cuda_peak_allocated_bytes": summary.get("cuda_peak_allocated_bytes"),
        "configuration": {
            "micro_batch_size": cfg.training.micro_batch_size,
            "gradient_accumulation": cfg.training.gradient_accumulation,
            "precision": cfg.training.precision,
            "fused_optimizer": cfg.training.fused_optimizer,
            "packing": cfg.data.packing,
            "attention_backend": cfg.model.attention_backend,
            "activation_checkpointing": cfg.model.activation_checkpointing,
        },
    }


def build_time_energy_frontier(
    baseline: str | Path,
    candidates: list[str | Path],
    *,
    quality_tolerance: float = 0.01,
    output_dir: str | Path = "artifacts/frontiers",
) -> dict[str, Any]:
    if not 0 <= quality_tolerance <= 0.1:
        raise ValueError("quality_tolerance must be between 0 and 0.1")
    baseline_path = resolve_run(baseline)
    baseline_summary = json.loads(
        (baseline_path / "metrics.summary.json").read_text(encoding="utf-8")
    )
    baseline_cfg = ExperimentConfig.from_dict(
        json.loads((baseline_path / "spec.resolved.json").read_text(encoding="utf-8"))
    )
    baseline_final_nll = float(baseline_summary["evaluations"][-1]["validation_nll"])
    target_nll = baseline_final_nll * (1.0 + quality_tolerance)
    signature = _semantic_signature(baseline_cfg)
    expected_tokens = int(baseline_summary["tokens"])
    unique_runs = [baseline, *candidates]
    records = [
        analyze_run_to_target(
            run,
            target_nll=target_nll,
            reference_signature=signature,
            expected_tokens=expected_tokens,
        )
        for run in unique_runs
    ]
    eligible = [
        item
        for item in records
        if item["eligible"]
        and item["time_to_target_seconds"] is not None
        and item["gpu_board_energy_to_target_joules"] is not None
    ]
    pareto: list[dict[str, Any]] = []
    for item in eligible:
        dominated = any(
            other is not item
            and float(other["time_to_target_seconds"]) <= float(item["time_to_target_seconds"])
            and float(other["gpu_board_energy_to_target_joules"])
            <= float(item["gpu_board_energy_to_target_joules"])
            and (
                float(other["time_to_target_seconds"]) < float(item["time_to_target_seconds"])
                or float(other["gpu_board_energy_to_target_joules"])
                < float(item["gpu_board_energy_to_target_joules"])
            )
            for other in eligible
        )
        if not dominated:
            pareto.append(item)
    report = {
        "schema_version": 1,
        "frontier": "molt-fixed-workload-time-energy",
        "created_utc": datetime.now(UTC).isoformat(),
        "baseline_run": baseline_path.name,
        "baseline_final_validation_nll": baseline_final_nll,
        "quality_tolerance": quality_tolerance,
        "target_validation_nll": target_nll,
        "semantic_signature": signature,
        "records": records,
        "pareto_run_ids": [item["run_id"] for item in pareto],
        "measurement_limit": (
            "Energy-to-target integrates sampled NVML board power from the first telemetry sample "
            "to the linearly interpolated validation crossing. Repeats are required for promotion."
        ),
    }
    output_root = Path(output_dir)
    output_root.mkdir(parents=True, exist_ok=True)
    output_path = output_root / f"time-energy-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    atomic_json(output_path, report)
    report["artifact_path"] = str(output_path)
    return report
