from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import torch
from tokenizers import Tokenizer

from ai_local.core.config import ExperimentConfig
from ai_local.data.bytes import ByteBatcher
from ai_local.experiments.store import resolve_checkpoint, resolve_run
from ai_local.training.engine import evaluate
from ai_local.training.model import ByteTransformer
from ai_local.training.model import resolve_dtype


def evaluate_run(run: str | Path) -> dict[str, Any]:
    path = resolve_run(run)
    cfg = ExperimentConfig.from_dict(json.loads((path / "spec.resolved.json").read_text(encoding="utf-8")))
    device = torch.device(cfg.training.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("run requires CUDA")
    model = ByteTransformer(cfg, device)
    checkpoint = torch.load(resolve_checkpoint(path), map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model"])
    manifest = json.loads((Path(cfg.data.prepared_dir) / "manifest.json").read_text(encoding="utf-8"))
    metrics = evaluate(
        model,
        cfg,
        manifest["validation"]["path"],
        device,
        str(manifest.get("storage_dtype", "uint8")),
        manifest["validation"].get("loss_mask_path"),
    )
    return {"run_id": path.name, "step": checkpoint["step"], "tokens": checkpoint["tokens"], **metrics}


@torch.inference_mode()
def generate_run(
    run: str | Path,
    prompt: str,
    *,
    max_new_bytes: int = 128,
    temperature: float = 0.8,
    top_k: int = 40,
    seed: int = 1337,
) -> dict[str, Any]:
    if max_new_bytes <= 0:
        raise ValueError("max_new_bytes must be positive")
    if temperature < 0:
        raise ValueError("temperature must be non-negative")
    if top_k <= 0 or top_k > 256:
        raise ValueError("top_k must be between 1 and 256")
    path = resolve_run(run)
    cfg = ExperimentConfig.from_dict(
        json.loads((path / "spec.resolved.json").read_text(encoding="utf-8"))
    )
    device = torch.device(cfg.training.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("run requires CUDA")
    model = ByteTransformer(cfg, device)
    checkpoint = torch.load(resolve_checkpoint(path), map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model"])
    model.eval()
    manifest = json.loads(
        (Path(cfg.data.prepared_dir) / "manifest.json").read_text(encoding="utf-8")
    )
    tokenizer_record = manifest.get("tokenizer")
    tokenizer = Tokenizer.from_file(tokenizer_record["path"]) if tokenizer_record else None
    stop_token_id = tokenizer.token_to_id("<|endoftext|>") if tokenizer else None
    encoded = tokenizer.encode(prompt, add_special_tokens=False).ids if tokenizer else list(prompt.encode("utf-8"))
    if not encoded:
        raise ValueError("prompt must not be empty")
    generated = encoded.copy()
    generator = torch.Generator(device=device).manual_seed(seed)
    for _ in range(max_new_bytes):
        context_capacity = cfg.model.max_context_length or cfg.data.context_length
        context = generated[-context_capacity:]
        tokens = torch.tensor(context, dtype=torch.long, device=device)[None, :]
        autocast_enabled = device.type == "cuda" and cfg.training.precision != "float32"
        with torch.autocast(
            device_type=device.type,
            dtype=resolve_dtype(cfg.training.precision),
            enabled=autocast_enabled,
        ):
            logits, _ = model(tokens)
        next_logits = logits[0, -1].float()
        if temperature == 0:
            next_token = int(next_logits.argmax())
        else:
            next_logits = next_logits / temperature
            values, indices = torch.topk(next_logits, min(top_k, next_logits.numel()))
            probabilities = torch.softmax(values, dim=-1)
            selected = torch.multinomial(probabilities, 1, generator=generator)
            next_token = int(indices[selected])
        generated.append(next_token)
        if stop_token_id is not None and next_token == stop_token_id:
            break

    completion_ids = generated[len(encoded) :]
    if tokenizer:
        completion = tokenizer.decode(completion_ids, skip_special_tokens=True)
    else:
        completion = bytes(completion_ids).decode("utf-8", errors="replace")
    result = {
        "run_id": path.name,
        "checkpoint_step": int(checkpoint["step"]),
        "checkpoint_tokens": int(checkpoint["tokens"]),
        "prompt": prompt,
        "completion": completion,
        "completion_token_ids": completion_ids,
        "temperature": temperature,
        "top_k": top_k,
        "seed": seed,
        "stopped_on_endoftext": bool(
            stop_token_id is not None and completion_ids and completion_ids[-1] == stop_token_id
        ),
    }
    if tokenizer is None:
        result["completion_byte_ids"] = completion_ids
    return result


def compare_runs(baseline: str | Path, candidate: str | Path) -> dict[str, Any]:
    left_path, right_path = resolve_run(baseline), resolve_run(candidate)
    left = json.loads((left_path / "metrics.summary.json").read_text(encoding="utf-8"))
    right = json.loads((right_path / "metrics.summary.json").read_text(encoding="utf-8"))
    compatible = left["model"]["total_parameters"] == right["model"]["total_parameters"]

    def ratio(key: str) -> float | None:
        a, b = left.get(key), right.get(key)
        return (float(a) / float(b)) if a is not None and b not in (None, 0) else None

    quality_key = (
        "validation_bits_per_byte"
        if "validation_bits_per_byte" in left["evaluations"][-1]
        and "validation_bits_per_byte" in right["evaluations"][-1]
        else "validation_bits_per_token"
    )
    baseline_final = left["evaluations"][-1][quality_key]
    candidate_final = right["evaluations"][-1][quality_key]
    target = baseline_final

    def first_crossing(evaluations: list[dict[str, Any]], target_value: float) -> dict[str, float] | None:
        for index, current in enumerate(evaluations):
            if current[quality_key] <= target_value:
                if index == 0:
                    return {"seconds": float(current["elapsed_seconds"]), "tokens": float(current["tokens"])}
                previous = evaluations[index - 1]
                high, low = previous[quality_key], current[quality_key]
                fraction = 1.0 if high == low else (high - target_value) / (high - low)
                fraction = min(1.0, max(0.0, fraction))
                return {
                    "seconds": previous["elapsed_seconds"] + fraction * (current["elapsed_seconds"] - previous["elapsed_seconds"]),
                    "tokens": previous["tokens"] + fraction * (current["tokens"] - previous["tokens"]),
                }
        return None

    left_target = first_crossing(left["evaluations"], target)
    right_target = first_crossing(right["evaluations"], target)
    target_speedup = None
    target_token_ratio = None
    if left_target and right_target and right_target["seconds"]:
        target_speedup = left_target["seconds"] / right_target["seconds"]
        target_token_ratio = left_target["tokens"] / right_target["tokens"] if right_target["tokens"] else None
    return {
        "baseline": left_path.name,
        "candidate": right_path.name,
        "compatible_parameter_count": compatible,
        "time_speedup_baseline_over_candidate": ratio("total_seconds"),
        "throughput_ratio_candidate_over_baseline": (
            right["tokens_per_second_end_to_end"] / left["tokens_per_second_end_to_end"]
            if left["tokens_per_second_end_to_end"]
            else None
        ),
        f"final_{quality_key.removeprefix('validation_')}": {
            "baseline": baseline_final,
            "candidate": candidate_final,
        },
        "quality_relative_change": (candidate_final - baseline_final) / baseline_final,
        "target_bits_per_byte": target,
        "time_to_target": {"baseline": left_target, "candidate": right_target},
        "time_to_target_speedup": target_speedup,
        "tokens_to_target_ratio": target_token_ratio,
        "warning": None if compatible else "parameter counts differ; this is not a controlled method comparison",
    }
