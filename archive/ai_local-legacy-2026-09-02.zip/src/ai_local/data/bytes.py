from __future__ import annotations

import os
import shutil
from array import array
from pathlib import Path

import torch
from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers

from ai_local.core.config import ExperimentConfig
from ai_local.core.io import atomic_json, sha256_file


SYNTHETIC_CORPUS = (
    b"Once upon a time a small machine learned a careful pattern. "
    b"It measured every result, kept every failure, and tried again.\n"
)

COPY_CHUNK_BYTES = 8 * 1024 * 1024


def _write_repeated(path: Path, size: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    remaining = size
    with temporary.open("wb") as handle:
        while remaining:
            chunk = SYNTHETIC_CORPUS[: min(remaining, len(SYNTHETIC_CORPUS))]
            handle.write(chunk)
            remaining -= len(chunk)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def _copy_range(source: Path, destination: Path, start: int, size: int) -> None:
    """Atomically copy a bounded file range without loading the corpus into RAM."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    remaining = size
    with source.open("rb") as reader, temporary.open("wb") as writer:
        reader.seek(start)
        while remaining:
            chunk = reader.read(min(remaining, COPY_CHUNK_BYTES))
            if not chunk:
                raise ValueError("source ended before the requested data split")
            writer.write(chunk)
            remaining -= len(chunk)
        writer.flush()
        os.fsync(writer.fileno())
    os.replace(temporary, destination)


def _safe_text_split(source: Path, requested: int) -> int:
    size = source.stat().st_size
    if requested >= size:
        raise ValueError("text training split leaves no validation data")
    with source.open("rb") as handle:
        handle.seek(requested)
        return min(size, requested + len(handle.readline()))


def _encode_text(
    tokenizer: Tokenizer,
    source: Path,
    destination: Path,
    loss_mask_destination: Path | None = None,
) -> int:
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    mask_temporary = (
        loss_mask_destination.with_suffix(loss_mask_destination.suffix + ".tmp")
        if loss_mask_destination
        else None
    )
    token_count = 0
    mask_writer = mask_temporary.open("wb") if mask_temporary else None
    answer_id = tokenizer.token_to_id("<|answer|>")
    end_id = tokenizer.token_to_id("<|endoftext|>")
    with source.open("r", encoding="utf-8") as reader, temporary.open("wb") as writer:
        for line in reader:
            ids = tokenizer.encode(line, add_special_tokens=False).ids
            values = array("I", ids)
            values.tofile(writer)
            if mask_writer:
                include = False
                mask = array("B")
                for token_id in ids:
                    if token_id == answer_id:
                        include = True
                        mask.append(0)
                    else:
                        mask.append(1 if include else 0)
                    if token_id == end_id:
                        include = False
                mask.tofile(mask_writer)
            token_count += len(ids)
        writer.flush()
        os.fsync(writer.fileno())
    if mask_writer and mask_temporary and loss_mask_destination:
        mask_writer.flush()
        os.fsync(mask_writer.fileno())
        mask_writer.close()
        os.replace(mask_temporary, loss_mask_destination)
    os.replace(temporary, destination)
    return token_count


def _prepare_bpe(cfg: ExperimentConfig, root: Path) -> dict[str, object]:
    if not cfg.data.source:
        raise ValueError("text_bpe data requires data.source")
    source = Path(cfg.data.source)
    source_size = source.stat().st_size
    split = _safe_text_split(source, min(cfg.data.train_bytes, int(source_size * 0.95)))
    validation_size = min(cfg.data.validation_bytes, source_size - split)
    if validation_size <= cfg.data.context_length:
        raise ValueError("text source is too small for the validation split")
    train_text = root / "train.txt"
    validation_text = root / "validation.txt"
    _copy_range(source, train_text, 0, split)
    _copy_range(source, validation_text, split, validation_size)

    tokenizer_path = root / "tokenizer.json"
    if cfg.data.tokenizer_path:
        tokenizer = Tokenizer.from_file(cfg.data.tokenizer_path)
        shutil.copyfile(cfg.data.tokenizer_path, tokenizer_path)
    else:
        tokenizer = Tokenizer(models.BPE(unk_token="<|unk|>"))
        tokenizer.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
        tokenizer.decoder = decoders.ByteLevel()
        trainer = trainers.BpeTrainer(
            vocab_size=cfg.data.vocab_size,
            min_frequency=2,
            initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),
            special_tokens=[
                "<|pad|>",
                "<|unk|>",
                "<|bos|>",
                "<|endoftext|>",
                "<|question|>",
                "<|answer|>",
            ],
        )
        tokenizer.train([str(train_text)], trainer)
        tokenizer.save(str(tokenizer_path))
    actual_vocab = tokenizer.get_vocab_size()
    if actual_vocab > cfg.data.vocab_size:
        raise ValueError(
            f"tokenizer vocabulary {actual_vocab} exceeds configured {cfg.data.vocab_size}"
        )

    train = root / "train.bin"
    validation = root / "validation.bin"
    qa = cfg.data.kind == "text_bpe_qa"
    train_mask = root / "train.loss-mask.bin" if qa else None
    validation_mask = root / "validation.loss-mask.bin" if qa else None
    train_tokens = _encode_text(tokenizer, train_text, train, train_mask)
    validation_tokens = _encode_text(tokenizer, validation_text, validation, validation_mask)
    return {
        "schema_version": 2,
        "kind": cfg.data.kind,
        "context_length": cfg.data.context_length,
        "vocab_size": cfg.data.vocab_size,
        "tokenizer_vocab_size": actual_vocab,
        "storage_dtype": "int32",
        "tokenizer": {
            "type": "bytelevel_bpe",
            "path": str(tokenizer_path),
            "sha256": sha256_file(tokenizer_path),
        },
        "train": {
            "path": str(train),
            "bytes": train.stat().st_size,
            "tokens": train_tokens,
            "source_bytes": train_text.stat().st_size,
            "sha256": sha256_file(train),
            **(
                {"loss_mask_path": str(train_mask), "loss_mask_sha256": sha256_file(train_mask)}
                if train_mask
                else {}
            ),
        },
        "validation": {
            "path": str(validation),
            "bytes": validation.stat().st_size,
            "tokens": validation_tokens,
            "source_bytes": validation_text.stat().st_size,
            "sha256": sha256_file(validation),
            **(
                {
                    "loss_mask_path": str(validation_mask),
                    "loss_mask_sha256": sha256_file(validation_mask),
                }
                if validation_mask
                else {}
            ),
        },
    }


def prepare(cfg: ExperimentConfig) -> dict[str, object]:
    root = Path(cfg.data.prepared_dir)
    root.mkdir(parents=True, exist_ok=True)
    if cfg.data.kind in {"text_bpe", "text_bpe_qa"}:
        manifest = _prepare_bpe(cfg, root)
        atomic_json(root / "manifest.json", manifest)
        return manifest
    train = root / "train.bin"
    validation = root / "validation.bin"
    if cfg.data.kind == "synthetic":
        _write_repeated(train, cfg.data.train_bytes)
        _write_repeated(validation, cfg.data.validation_bytes)
    else:
        if not cfg.data.source:
            raise ValueError("file data requires data.source")
        source = Path(cfg.data.source)
        source_size = source.stat().st_size
        if source_size < cfg.data.context_length + 2:
            raise ValueError("source is too small for one training example")
        split = min(
            cfg.data.train_bytes,
            max(cfg.data.context_length + 1, int(source_size * 0.9)),
        )
        _copy_range(source, train, 0, split)
        validation_start = split if source_size - split > cfg.data.context_length else 0
        validation_size = min(cfg.data.validation_bytes, source_size - validation_start)
        if validation_size <= cfg.data.context_length:
            raise ValueError("source is too small for the requested validation split")
        _copy_range(source, validation, validation_start, validation_size)
    manifest = {
        "schema_version": 1,
        "kind": cfg.data.kind,
        "context_length": cfg.data.context_length,
        "vocab_size": cfg.data.vocab_size,
        "storage_dtype": "uint8",
        "train": {"path": str(train), "bytes": train.stat().st_size, "sha256": sha256_file(train)},
        "validation": {
            "path": str(validation),
            "bytes": validation.stat().st_size,
            "sha256": sha256_file(validation),
        },
    }
    atomic_json(root / "manifest.json", manifest)
    return manifest


class ByteBatcher:
    def __init__(
        self,
        path: str | Path,
        context_length: int,
        seed: int,
        device: torch.device,
        *,
        storage_dtype: str = "uint8",
        sampling: str = "random",
        loss_mask_path: str | Path | None = None,
        packing: str = "indexed",
    ):
        source = Path(path)
        size = source.stat().st_size
        dtypes = {"uint8": torch.uint8, "int32": torch.int32}
        if storage_dtype not in dtypes:
            raise ValueError(f"unsupported token storage dtype: {storage_dtype}")
        element_size = torch.empty((), dtype=dtypes[storage_dtype]).element_size()
        if size % element_size:
            raise ValueError("token file size is not aligned to its storage dtype")
        token_count = size // element_size
        if token_count <= context_length:
            raise ValueError("prepared split is shorter than context_length + 1")
        # Memory mapping keeps dataset capacity independent of system RAM. The OS
        # page cache decides what stays resident, so a multi-terabyte corpus does
        # not become a multi-terabyte Python allocation.
        self.data = torch.from_file(
            str(source), shared=False, size=token_count, dtype=dtypes[storage_dtype]
        )
        self.storage_backend = "mmap"
        self.storage_dtype = storage_dtype
        self.source_path = source
        self.context_length = context_length
        self.window = torch.arange(context_length + 1, dtype=torch.int64)
        self.generator = torch.Generator(device="cpu").manual_seed(seed)
        self.device = device
        self.samples_drawn = 0
        self.tokens_drawn = 0
        self.sequential_cursor = 0
        self.sampling = sampling
        if packing not in {"indexed", "contiguous"}:
            raise ValueError("packing must be indexed or contiguous")
        self.packing = packing
        self.loss_mask = None
        if loss_mask_path:
            mask_source = Path(loss_mask_path)
            if mask_source.stat().st_size != token_count:
                raise ValueError("loss mask length differs from token stream length")
            self.loss_mask = torch.from_file(
                str(mask_source), shared=False, size=token_count, dtype=torch.uint8
            )

    def batch(self, batch_size: int) -> tuple[torch.Tensor, torch.Tensor]:
        high = len(self.data) - self.context_length - 1
        if self.sampling == "random":
            offsets = torch.randint(0, high + 1, (batch_size,), generator=self.generator)
        else:
            offsets = (
                self.sequential_cursor
                + torch.arange(batch_size, dtype=torch.int64) * self.context_length
            ) % (high + 1)
            self.sequential_cursor = int(
                (self.sequential_cursor + batch_size * self.context_length) % (high + 1)
            )
        contiguous_end = int(offsets[0]) + batch_size * self.context_length
        use_contiguous = (
            self.packing == "contiguous"
            and self.sampling == "sequential"
            and contiguous_end < len(self.data)
        )
        if use_contiguous:
            start = int(offsets[0])
            windows = self.data[start : contiguous_end + 1].unfold(
                0, self.context_length + 1, self.context_length
            )
            target_mask = (
                self.loss_mask[start + 1 : contiguous_end + 1].unfold(
                    0, self.context_length, self.context_length
                )
                if self.loss_mask is not None
                else None
            )
        else:
            indices = offsets[:, None] + self.window[None, :]
            windows = self.data[indices]
            target_mask = self.loss_mask[indices[:, 1:]] if self.loss_mask is not None else None
        self.samples_drawn += batch_size
        self.tokens_drawn += batch_size * self.context_length
        if self.device.type == "cuda":
            # Transfer the compact storage representation, then widen on-device.
            windows = windows.to(self.device, non_blocking=True).long()
        else:
            windows = windows.long()
        targets = windows[:, 1:]
        if target_mask is not None:
            target_mask = target_mask.to(self.device, non_blocking=True)
            targets = targets.masked_fill(target_mask == 0, -100)
        return windows[:, :-1], targets

    def state_dict(self) -> dict[str, object]:
        return {
            "generator_state": self.generator.get_state(),
            "samples_drawn": self.samples_drawn,
            "tokens_drawn": self.tokens_drawn,
            "sequential_cursor": self.sequential_cursor,
            "sampling": self.sampling,
            "packing": self.packing,
        }

    def load_state_dict(self, state: dict[str, object]) -> None:
        self.generator.set_state(state["generator_state"])  # type: ignore[arg-type]
        self.samples_drawn = int(state["samples_drawn"])
        self.tokens_drawn = int(state.get("tokens_drawn", self.samples_drawn * self.context_length))
        self.sequential_cursor = int(state.get("sequential_cursor", 0))
        if state.get("sampling", self.sampling) != self.sampling:
            raise ValueError("checkpoint sampling mode differs from configuration")
        if state.get("packing", self.packing) != self.packing:
            raise ValueError("checkpoint packing mode differs from configuration")
