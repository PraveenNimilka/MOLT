"""Deterministic byte datasets."""
