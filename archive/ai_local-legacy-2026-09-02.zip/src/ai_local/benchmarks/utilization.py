from __future__ import annotations

import gc
import json
import time
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import torch

from ai_local.benchmarks.saturation import _one_step
from ai_local.core.config import ExperimentConfig
from ai_local.core.io import atomic_json, sha256_file
from ai_local.data.bytes import ByteBatcher
from ai_local.measurement.telemetry import Telemetry
from ai_local.training.model import ByteTransformer
from ai_local.training.optimizers import build_optimizer


def utilization_probe(
    cfg: ExperimentConfig,
    micro_batches: list[int],
    *,
    warmup_steps: int = 3,
    measured_steps: int = 20,
    precision: str | None = None,
    packing: str | None = None,
    attention_backend: str | None = None,
    fused_optimizer: bool | None = None,
    output_dir: str | Path = "artifacts/benchmarks",
) -> dict[str, Any]:
    """Cheap effective-batch-preserving time/energy kill test."""

    cfg = replace(
        cfg,
        data=replace(cfg.data, packing=packing or cfg.data.packing),
        model=replace(
            cfg.model, attention_backend=attention_backend or cfg.model.attention_backend
        ),
        training=replace(
            cfg.training,
            precision=precision or cfg.training.precision,
            fused_optimizer=(
                cfg.training.fused_optimizer if fused_optimizer is None else fused_optimizer
            ),
        ),
    )
    cfg.validate()
    if cfg.training.device != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("utilization probe requires configured CUDA")
    if min(micro_batches) <= 0 or warmup_steps < 0 or measured_steps <= 0:
        raise ValueError("invalid probe shape or step count")
    effective_sequences = cfg.training.micro_batch_size * cfg.training.gradient_accumulation
    manifest_path = Path(cfg.data.prepared_dir) / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    train_record = manifest["train"]
    if sha256_file(train_record["path"]) != train_record["sha256"]:
        raise ValueError("train data hash mismatch")
    device = torch.device("cuda")
    records: list[dict[str, Any]] = []
    for micro_batch in micro_batches:
        if effective_sequences % micro_batch:
            records.append(
                {
                    "status": "invalid_effective_batch",
                    "micro_batch_size": micro_batch,
                    "effective_sequences_per_update": effective_sequences,
                }
            )
            continue
        accumulation = effective_sequences // micro_batch
        candidate = replace(
            cfg,
            training=replace(
                cfg.training,
                micro_batch_size=micro_batch,
                gradient_accumulation=accumulation,
            ),
        )
        model = optimizer = batcher = None
        telemetry = None
        try:
            gc.collect()
            torch.cuda.empty_cache()
            torch.manual_seed(cfg.seed)
            torch.cuda.manual_seed_all(cfg.seed)
            model = ByteTransformer(candidate, device)
            optimizer = build_optimizer(model, candidate)
            batcher = ByteBatcher(
                train_record["path"],
                cfg.data.context_length,
                cfg.seed,
                device,
                storage_dtype=str(manifest.get("storage_dtype", "uint8")),
                sampling=cfg.data.sampling,
                loss_mask_path=train_record.get("loss_mask_path"),
                packing=cfg.data.packing,
            )
            for _ in range(warmup_steps):
                _one_step(model, optimizer, batcher, candidate)
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
            telemetry = Telemetry(0.05, enable_gpu=True)
            telemetry.start()
            losses: list[float] = []
            tokens = 0
            data_seconds = 0.0
            started = time.perf_counter()
            for _ in range(measured_steps):
                loss, step_tokens, enqueue = _one_step(model, optimizer, batcher, candidate)
                losses.append(loss)
                tokens += step_tokens
                data_seconds += enqueue
            torch.cuda.synchronize()
            seconds = time.perf_counter() - started
            telemetry_summary = telemetry.stop()
            telemetry = None
            samples = telemetry_summary["samples"]
            powered = [float(item["gpu_power_watts"]) for item in samples if item["gpu_power_watts"] is not None]
            utilized = [
                float(item["gpu_utilization_percent"])
                for item in samples
                if item["gpu_utilization_percent"] is not None
            ]
            graphics_clocks = [
                float(item["gpu_graphics_clock_mhz"])
                for item in samples
                if item.get("gpu_graphics_clock_mhz") is not None
            ]
            temperatures = [
                float(item["gpu_temperature_c"])
                for item in samples
                if item.get("gpu_temperature_c") is not None
            ]
            performance_states = sorted(
                {int(item["gpu_performance_state"]) for item in samples if item.get("gpu_performance_state") is not None}
            )
            enforced_limits = [
                float(item["gpu_enforced_power_limit_watts"])
                for item in samples
                if item.get("gpu_enforced_power_limit_watts") is not None
            ]
            throttle_reasons = sorted(
                {int(item["gpu_clock_throttle_reasons"]) for item in samples if item.get("gpu_clock_throttle_reasons") is not None}
            )
            energy = telemetry_summary["gpu_board_energy_joules"]
            records.append(
                {
                    "status": "ok",
                    "micro_batch_size": micro_batch,
                    "gradient_accumulation": accumulation,
                    "effective_sequences_per_update": effective_sequences,
                    "effective_tokens_per_update": effective_sequences * cfg.data.context_length,
                    "measured_steps": measured_steps,
                    "tokens": tokens,
                    "seconds": seconds,
                    "tokens_per_second": tokens / seconds,
                    "gpu_board_energy_joules": energy,
                    "joules_per_million_tokens": (
                        float(energy) * 1_000_000 / tokens if energy is not None else None
                    ),
                    "mean_gpu_power_watts": sum(powered) / len(powered) if powered else None,
                    "mean_gpu_utilization_percent": sum(utilized) / len(utilized) if utilized else None,
                    "mean_gpu_graphics_clock_mhz": (
                        sum(graphics_clocks) / len(graphics_clocks) if graphics_clocks else None
                    ),
                    "minimum_gpu_graphics_clock_mhz": min(graphics_clocks) if graphics_clocks else None,
                    "maximum_gpu_graphics_clock_mhz": max(graphics_clocks) if graphics_clocks else None,
                    "minimum_gpu_temperature_c": min(temperatures) if temperatures else None,
                    "maximum_gpu_temperature_c": max(temperatures) if temperatures else None,
                    "gpu_performance_states": performance_states,
                    "minimum_gpu_enforced_power_limit_watts": (
                        min(enforced_limits) if enforced_limits else None
                    ),
                    "maximum_gpu_enforced_power_limit_watts": (
                        max(enforced_limits) if enforced_limits else None
                    ),
                    "gpu_clock_throttle_reasons": throttle_reasons,
                    "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
                    "data_enqueue_seconds": data_seconds,
                    "first_loss": losses[0],
                    "last_loss": losses[-1],
                }
            )
        except torch.OutOfMemoryError as exc:
            records.append(
                {
                    "status": "out_of_memory",
                    "micro_batch_size": micro_batch,
                    "gradient_accumulation": accumulation,
                    "error": str(exc),
                }
            )
        except RuntimeError as exc:
            records.append(
                {
                    "status": "unsupported_or_failed",
                    "micro_batch_size": micro_batch,
                    "gradient_accumulation": accumulation,
                    "error": str(exc),
                }
            )
        finally:
            if telemetry is not None:
                telemetry.stop()
            del batcher, optimizer, model
            gc.collect()
            torch.cuda.empty_cache()
    successful = [item for item in records if item["status"] == "ok"]
    report: dict[str, Any] = {
        "schema_version": 1,
        "benchmark": "molt-effective-batch-utilization-probe",
        "created_utc": datetime.now(UTC).isoformat(),
        "config": cfg.to_dict(),
        "effective_sequences_per_update": effective_sequences,
        "records": records,
        "fastest": min(successful, key=lambda item: item["seconds"]) if successful else None,
        "lowest_energy": (
            min(successful, key=lambda item: float(item["gpu_board_energy_joules"]))
            if successful and all(item["gpu_board_energy_joules"] is not None for item in successful)
            else None
        ),
        "interpretation_limit": (
            "This is a fixed-step kill test. Promotion requires full end-to-end time and energy "
            "to the preregistered validation-NLL target with repeats."
        ),
    }
    output_root = Path(output_dir)
    output_root.mkdir(parents=True, exist_ok=True)
    output_path = output_root / f"utilization-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    atomic_json(output_path, report)
    report["artifact_path"] = str(output_path)
    return report
