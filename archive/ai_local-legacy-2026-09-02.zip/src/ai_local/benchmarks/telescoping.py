from __future__ import annotations

import json
import math
import time
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import torch

from ai_local.core.config import ExperimentConfig
from ai_local.core.io import atomic_json, sha256_file
from ai_local.data.bytes import ByteBatcher
from ai_local.methods.telescoping_context import (
    analytic_probability_frontier,
    coupled_suffix_loss,
    telescoping_context_loss,
)
from ai_local.training.model import ByteTransformer, resolve_dtype


def _gradient_geometry(
    model: ByteTransformer, reference: list[torch.Tensor]
) -> tuple[float, float, float]:
    dot = torch.zeros((), device=reference[0].device, dtype=torch.float64)
    norm = torch.zeros_like(dot)
    error = torch.zeros_like(dot)
    for parameter, target in zip(model.parameters(), reference):
        if parameter.grad is None:
            raise RuntimeError("estimator left a parameter gradient unset")
        gradient = parameter.grad.detach()
        dot += torch.sum(gradient.double() * target.double())
        norm += torch.sum(gradient.double().square())
        error += torch.sum((gradient.double() - target.double()).square())
    return float(dot), float(norm), float(error)


def telescoping_probe(
    cfg: ExperimentConfig,
    *,
    levels: tuple[int, ...],
    probabilities: tuple[float, ...],
    target_tokens: int,
    micro_batch_size: int,
    samples: int,
    output_dir: str | Path = "artifacts/benchmarks",
) -> dict[str, Any]:
    """Measure estimator cost and variance without performing optimizer updates."""

    cfg.validate()
    if cfg.training.device != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("telescoping probe requires configured CUDA")
    if samples <= 0 or micro_batch_size <= 0:
        raise ValueError("samples and micro_batch_size must be positive")
    if levels[-1] != cfg.data.context_length:
        raise ValueError("longest level must equal configured data context_length")
    manifest_path = Path(cfg.data.prepared_dir) / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    train_record = manifest["train"]
    if sha256_file(train_record["path"]) != train_record["sha256"]:
        raise ValueError("train data hash mismatch")

    device = torch.device("cuda")
    torch.manual_seed(cfg.seed)
    torch.cuda.manual_seed_all(cfg.seed)
    probe_cfg = replace(cfg, training=replace(cfg.training, micro_batch_size=micro_batch_size))
    model = ByteTransformer(probe_cfg, device)
    batcher = ByteBatcher(
        train_record["path"],
        levels[-1],
        cfg.seed,
        device,
        storage_dtype=str(manifest.get("storage_dtype", "uint8")),
        sampling=cfg.data.sampling,
        packing=cfg.data.packing,
    )
    tokens, targets = batcher.batch(micro_batch_size)
    autocast = lambda: torch.autocast(
        device_type="cuda",
        dtype=resolve_dtype(cfg.training.precision),
        enabled=cfg.training.precision != "float32",
    )

    # Warm every shape before timing so CUDA kernel/library initialization is
    # not charged only to the exact reference.
    for context in levels:
        model.zero_grad(set_to_none=True)
        with autocast():
            warmup_loss = coupled_suffix_loss(
                model,
                tokens,
                targets,
                context_length=context,
                full_context_length=levels[-1],
                target_tokens=target_tokens,
            )
        warmup_loss.backward()
    torch.cuda.synchronize()

    # The reference is the exact longest-context gradient on the same suffix.
    model.zero_grad(set_to_none=True)
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    with autocast():
        reference_loss = coupled_suffix_loss(
            model,
            tokens,
            targets,
            context_length=levels[-1],
            full_context_length=levels[-1],
            target_tokens=target_tokens,
        )
    reference_loss.backward()
    torch.cuda.synchronize()
    reference_seconds = time.perf_counter() - started
    reference_peak = torch.cuda.max_memory_allocated()
    reference = [parameter.grad.detach().clone() for parameter in model.parameters()]
    reference_gradient_bytes = sum(item.numel() * item.element_size() for item in reference)
    reference_norm_sq = sum(float(torch.sum(item.double().square())) for item in reference)
    if not math.isfinite(reference_norm_sq) or reference_norm_sq == 0.0:
        raise FloatingPointError("reference gradient has invalid norm")

    # Profile each deterministic level and measure adjacent gradient deltas.
    # CPU copies keep this analysis from changing the candidate's GPU peak.
    level_costs: list[float] = []
    level_gradients_cpu: list[list[torch.Tensor]] = []
    for context in levels[:-1]:
        model.zero_grad(set_to_none=True)
        torch.cuda.synchronize()
        level_started = time.perf_counter()
        with autocast():
            level_loss = coupled_suffix_loss(
                model,
                tokens,
                targets,
                context_length=context,
                full_context_length=levels[-1],
                target_tokens=target_tokens,
            )
        level_loss.backward()
        torch.cuda.synchronize()
        level_costs.append(time.perf_counter() - level_started)
        level_gradients_cpu.append([parameter.grad.detach().cpu().clone() for parameter in model.parameters()])
    level_costs.append(reference_seconds)
    level_gradients_cpu.append([item.detach().cpu().clone() for item in reference])
    delta_ratios: list[float] = []
    for lower, upper in zip(level_gradients_cpu, level_gradients_cpu[1:]):
        delta_norm_sq = sum(
            float(torch.sum((high.double() - low.double()).square()))
            for low, high in zip(lower, upper)
        )
        delta_ratios.append(delta_norm_sq / reference_norm_sq)
    probability_frontier = analytic_probability_frontier(
        tuple(level_costs), tuple(delta_ratios)
    )
    del level_gradients_cpu

    generator = torch.Generator(device="cpu").manual_seed(cfg.seed + 991)
    records: list[dict[str, Any]] = []
    torch.cuda.reset_peak_memory_stats()
    for sample_index in range(samples):
        model.zero_grad(set_to_none=True)
        torch.cuda.synchronize()
        started = time.perf_counter()
        with autocast():
            estimate = telescoping_context_loss(
                model,
                tokens,
                targets,
                levels=levels,
                probabilities=probabilities,
                target_tokens=target_tokens,
                generator=generator,
            )
        estimate.loss.backward()
        torch.cuda.synchronize()
        seconds = time.perf_counter() - started
        dot, norm_sq, error_sq = _gradient_geometry(model, reference)
        cosine = dot / math.sqrt(max(norm_sq * reference_norm_sq, 1e-300))
        records.append(
            {
                "sample": sample_index,
                "seconds": seconds,
                "sampled_corrections": list(estimate.sampled_corrections),
                "evaluated_contexts": list(estimate.evaluated_contexts),
                "loss_estimate": float(estimate.loss.detach()),
                "gradient_norm_sq_ratio": norm_sq / reference_norm_sq,
                "gradient_error_sq_ratio": error_sq / reference_norm_sq,
                "gradient_cosine": cosine,
            }
        )
    candidate_peak = torch.cuda.max_memory_allocated()
    candidate_peak_adjusted = max(0, candidate_peak - reference_gradient_bytes)
    mean_seconds = sum(item["seconds"] for item in records) / samples
    second_moment_ratio = sum(item["gradient_norm_sq_ratio"] for item in records) / samples
    raw_speedup = reference_seconds / mean_seconds
    variance_adjusted_speedup = raw_speedup / second_moment_ratio
    mean_gradient_error = sum(item["gradient_error_sq_ratio"] for item in records) / samples
    mean_cosine = sum(item["gradient_cosine"] for item in records) / samples
    report: dict[str, Any] = {
        "schema_version": 1,
        "benchmark": "molt-telescoping-context-probe",
        "created_utc": datetime.now(UTC).isoformat(),
        "method_status": "experimental_not_novelty_verified",
        "config": probe_cfg.to_dict(),
        "levels": list(levels),
        "probabilities": list(probabilities),
        "target_tokens": target_tokens,
        "micro_batch_size": micro_batch_size,
        "samples": samples,
        "reference": {
            "loss": float(reference_loss.detach()),
            "seconds": reference_seconds,
            "gradient_norm_sq": reference_norm_sq,
            "peak_allocated_bytes": reference_peak,
            "stored_probe_gradient_bytes": reference_gradient_bytes,
        },
        "analytic_frontier": {
            "level_cost_seconds": level_costs,
            "adjacent_gradient_delta_norm_sq_ratios": delta_ratios,
            "best": probability_frontier[0],
            "top_five": probability_frontier[:5],
            "interpretation_limit": (
                "Uses measured isolated level costs and the exact independent-Bernoulli second "
                "moment identity. It is a screening proxy, not a convergence guarantee."
            ),
        },
        "candidate": {
            "mean_seconds": mean_seconds,
            "probe_peak_allocated_bytes": candidate_peak,
            "peak_allocated_bytes_excluding_stored_reference": candidate_peak_adjusted,
            "raw_step_speedup": raw_speedup,
            "gradient_second_moment_ratio": second_moment_ratio,
            "mean_gradient_error_sq_ratio": mean_gradient_error,
            "mean_gradient_cosine": mean_cosine,
            "variance_adjusted_speedup_proxy": variance_adjusted_speedup,
        },
        "records": records,
        "decision_rule": (
            "Reject before training if raw_step_speedup <2, variance-adjusted speedup proxy <1, "
            "non-finite values occur, or peak allocation exceeds the reference. The proxy is not "
            "a training-quality result."
        ),
    }
    output_root = Path(output_dir)
    output_root.mkdir(parents=True, exist_ok=True)
    output_path = output_root / f"telescoping-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    atomic_json(output_path, report)
    report["artifact_path"] = str(output_path)
    return report
