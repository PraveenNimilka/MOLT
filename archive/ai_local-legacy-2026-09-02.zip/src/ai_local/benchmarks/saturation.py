from __future__ import annotations

import gc
import json
import math
import time
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import torch

from ai_local.core.config import ExperimentConfig
from ai_local.core.io import atomic_json, sha256_file
from ai_local.data.bytes import ByteBatcher
from ai_local.training.model import ByteTransformer, model_stats, resolve_dtype
from ai_local.training.optimizers import build_optimizer


def _load_manifest(cfg: ExperimentConfig) -> dict[str, Any]:
    path = Path(cfg.data.prepared_dir) / "manifest.json"
    if not path.is_file():
        raise FileNotFoundError(f"prepared manifest missing: {path}; run ai-local prepare first")
    manifest = json.loads(path.read_text(encoding="utf-8"))
    train = manifest["train"]
    if sha256_file(train["path"]) != train["sha256"]:
        raise ValueError("train data hash mismatch")
    return manifest


def _autocast(cfg: ExperimentConfig):
    return torch.autocast(
        device_type="cuda",
        dtype=resolve_dtype(cfg.training.precision),
        enabled=cfg.training.precision != "float32",
    )


def _one_step(
    model: ByteTransformer,
    optimizer: torch.optim.Optimizer,
    batcher: ByteBatcher,
    cfg: ExperimentConfig,
) -> tuple[float, int, float]:
    optimizer.zero_grad(set_to_none=True)
    loss_total = 0.0
    token_count = 0
    data_seconds = 0.0
    for _ in range(cfg.training.gradient_accumulation):
        data_start = time.perf_counter()
        x, y = batcher.batch(cfg.training.micro_batch_size)
        data_seconds += time.perf_counter() - data_start
        with _autocast(cfg):
            _, loss = model(x, y)
            assert loss is not None
            scaled_loss = loss / cfg.training.gradient_accumulation
        if not torch.isfinite(loss):
            raise FloatingPointError(f"non-finite benchmark loss: {float(loss)}")
        scaled_loss.backward()
        loss_total += float(loss.detach())
        token_count += y.numel()
    torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.training.gradient_clip)
    optimizer.step()
    return loss_total / cfg.training.gradient_accumulation, token_count, data_seconds


def saturation_search(
    cfg: ExperimentConfig,
    contexts: list[int],
    micro_batches: list[int],
    *,
    warmup_steps: int = 1,
    measured_steps: int = 3,
    minimum_headroom_mib: int = 512,
    output_dir: str | Path = "artifacts/benchmarks",
) -> dict[str, Any]:
    """Search workload shapes without mutating the supplied training config.

    This benchmark ranks raw end-to-end training throughput. It does not claim
    equal convergence because changing sequence or micro-batch shape can change
    optimization behavior; recommended shapes require a later time-to-quality run.
    """
    cfg.validate()
    if not torch.cuda.is_available():
        raise RuntimeError("saturation search requires CUDA")
    if cfg.training.device != "cuda":
        raise ValueError("saturation search requires training.device=cuda")
    if min(contexts + micro_batches) <= 0 or warmup_steps < 0 or measured_steps <= 0:
        raise ValueError("contexts, micro-batches, and measured steps must be positive")

    manifest = _load_manifest(cfg)
    train_path = str(manifest["train"]["path"])
    storage_dtype = str(manifest.get("storage_dtype", "uint8"))
    device = torch.device("cuda")
    total_vram = torch.cuda.get_device_properties(device).total_memory
    minimum_headroom = minimum_headroom_mib * 1024**2
    results: list[dict[str, Any]] = []

    for context in contexts:
        for micro_batch in micro_batches:
            gc.collect()
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
            free_before, _ = torch.cuda.mem_get_info(device)
            external_and_runtime = total_vram - free_before
            candidate_cfg = replace(
                cfg,
                data=replace(cfg.data, context_length=context),
                training=replace(cfg.training, micro_batch_size=micro_batch),
            )
            model = None
            optimizer = None
            batcher = None
            try:
                torch.manual_seed(cfg.seed)
                torch.cuda.manual_seed_all(cfg.seed)
                torch.cuda.reset_peak_memory_stats(device)
                model = ByteTransformer(candidate_cfg, device)
                optimizer = build_optimizer(model, candidate_cfg)
                batcher = ByteBatcher(
                    train_path,
                    context,
                    cfg.seed,
                    device,
                    storage_dtype=storage_dtype,
                    sampling=cfg.data.sampling,
                    packing=cfg.data.packing,
                )
                for _ in range(warmup_steps):
                    _one_step(model, optimizer, batcher, candidate_cfg)
                torch.cuda.synchronize()
                torch.cuda.reset_peak_memory_stats(device)
                losses: list[float] = []
                tokens = 0
                data_seconds = 0.0
                started = time.perf_counter()
                for _ in range(measured_steps):
                    loss, step_tokens, step_data_seconds = _one_step(
                        model, optimizer, batcher, candidate_cfg
                    )
                    losses.append(loss)
                    tokens += step_tokens
                    data_seconds += step_data_seconds
                torch.cuda.synchronize()
                elapsed = time.perf_counter() - started
                peak_allocated = torch.cuda.max_memory_allocated(device)
                peak_reserved = torch.cuda.max_memory_reserved(device)
                estimated_device_headroom = max(
                    0, total_vram - external_and_runtime - peak_reserved
                )
                status = "ok" if estimated_device_headroom >= minimum_headroom else "insufficient_headroom"
                stats = model_stats(model)
                results.append(
                    {
                        "status": status,
                        "context_length": context,
                        "micro_batch_size": micro_batch,
                        "gradient_accumulation": candidate_cfg.training.gradient_accumulation,
                        "parameters": stats.total_parameters,
                        "measured_steps": measured_steps,
                        "tokens": tokens,
                        "seconds": elapsed,
                        "tokens_per_second": tokens / elapsed,
                        "data_enqueue_seconds": data_seconds,
                        "data_enqueue_fraction": data_seconds / elapsed,
                        "first_loss": losses[0],
                        "last_loss": losses[-1],
                        "cuda_peak_allocated_bytes": peak_allocated,
                        "cuda_peak_reserved_bytes": peak_reserved,
                        "estimated_device_headroom_bytes": estimated_device_headroom,
                    }
                )
            except torch.OutOfMemoryError as exc:
                results.append(
                    {
                        "status": "out_of_memory",
                        "context_length": context,
                        "micro_batch_size": micro_batch,
                        "error": str(exc),
                    }
                )
            finally:
                del batcher, optimizer, model
                gc.collect()
                torch.cuda.empty_cache()

    eligible = [item for item in results if item["status"] == "ok"]
    recommendation = max(eligible, key=lambda item: item["tokens_per_second"]) if eligible else None
    report: dict[str, Any] = {
        "schema_version": 1,
        "benchmark": "molt-saturation-search",
        "created_utc": datetime.now(UTC).isoformat(),
        "gpu": torch.cuda.get_device_name(device),
        "total_vram_bytes": total_vram,
        "minimum_headroom_bytes": minimum_headroom,
        "base_config": cfg.to_dict(),
        "candidates": results,
        "recommendation": recommendation,
        "interpretation_limit": (
            "Ranks raw training throughput only. A recommendation must pass an equal-quality, "
            "equal-token controlled experiment before promotion."
        ),
    }
    output_root = Path(output_dir)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    output_path = output_root / f"saturation-{stamp}.json"
    atomic_json(output_path, report)
    report["artifact_path"] = str(output_path)
    return report
