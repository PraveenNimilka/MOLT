from __future__ import annotations

import gc
import json
import time
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import torch

from ai_local.benchmarks.saturation import _one_step
from ai_local.core.config import ExperimentConfig
from ai_local.core.io import atomic_json
from ai_local.data.bytes import ByteBatcher
from ai_local.measurement.telemetry import Telemetry
from ai_local.methods.time_energy_controller import (
    ControllerObservation,
    LossConditionedTimeEnergyController,
)
from ai_local.training.model import ByteTransformer
from ai_local.training.optimizers import build_optimizer


def _run_policy(
    cfg: ExperimentConfig,
    manifest: dict[str, Any],
    *,
    actions: dict[str, tuple[int, int]],
    blocks: int,
    steps_per_block: int,
    controlled: bool,
) -> dict[str, Any]:
    device = torch.device("cuda")
    torch.manual_seed(cfg.seed)
    torch.cuda.manual_seed_all(cfg.seed)
    model = ByteTransformer(cfg, device)
    optimizer = build_optimizer(model, cfg)
    train_record = manifest["train"]
    batcher = ByteBatcher(
        train_record["path"], cfg.data.context_length, cfg.seed, device,
        storage_dtype=str(manifest.get("storage_dtype", "uint8")),
        sampling=cfg.data.sampling, loss_mask_path=train_record.get("loss_mask_path"),
        packing=cfg.data.packing,
    )
    controller = LossConditionedTimeEnergyController(
        list(actions), target_loss=3.55, minimum_improvement=0.01,
        exploration_blocks=2,
    )
    current = list(actions)[0]
    records: list[dict[str, Any]] = []
    total_seconds = 0.0
    total_energy = 0.0
    for block in range(blocks):
        if controlled:
            current = controller.choose(
                current_action=current,
                current_loss=records[-1]["loss_after"] if records else 10.0,
            )
        else:
            current = list(actions)[0]
        micro, accumulation = actions[current]
        candidate = replace(
            cfg,
            training=replace(
                cfg.training,
                micro_batch_size=micro,
                gradient_accumulation=accumulation,
            ),
        )
        torch.cuda.reset_peak_memory_stats()
        telemetry = Telemetry(0.05, enable_gpu=True)
        telemetry.start()
        losses: list[float] = []
        tokens = 0
        started = time.perf_counter()
        for _ in range(steps_per_block):
            loss, step_tokens, _ = _one_step(model, optimizer, batcher, candidate)
            losses.append(loss)
            tokens += step_tokens
        torch.cuda.synchronize()
        seconds = time.perf_counter() - started
        measured = telemetry.stop()
        energy = float(measured["gpu_board_energy_joules"])
        split = max(1, len(losses) // 2)
        loss_before = sum(losses[:split]) / len(losses[:split])
        loss_after = sum(losses[split:]) / len(losses[split:])
        peak = int(torch.cuda.max_memory_allocated())
        observation = ControllerObservation(
            action=current, seconds=seconds, joules=energy, tokens=tokens,
            loss_before=loss_before, loss_after=loss_after,
            peak_allocated_bytes=peak,
            total_vram_bytes=int(torch.cuda.get_device_properties(device).total_memory),
        )
        if controlled:
            controller.observe(observation)
        total_seconds += seconds
        total_energy += energy
        records.append(
            {
                "block": block + 1, "action": current, "micro_batch_size": micro,
                "gradient_accumulation": accumulation, "seconds": seconds,
                "gpu_board_energy_joules": energy, "tokens": tokens,
                "loss_before": loss_before, "loss_after": loss_after,
                "peak_allocated_bytes": peak,
                "enforced_power_limit_watts": [
                    measured.get("minimum_gpu_enforced_power_limit_watts"),
                    measured.get("maximum_gpu_enforced_power_limit_watts"),
                ],
            }
        )
    del batcher, optimizer, model
    gc.collect()
    torch.cuda.empty_cache()
    return {
        "policy": "controller" if controlled else "static_baseline",
        "total_seconds": total_seconds,
        "total_gpu_board_energy_joules": total_energy,
        "records": records,
        "decisions": controller.decisions if controlled else [],
    }


def controller_probe(
    cfg: ExperimentConfig,
    *,
    blocks: int = 8,
    steps_per_block: int = 10,
    output_dir: str | Path = "artifacts/benchmarks",
) -> dict[str, Any]:
    """Cheap live kill test against a same-budget static microbatch-24 policy."""
    cfg.validate()
    if cfg.training.device != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("controller probe requires configured CUDA")
    if blocks < 4 or steps_per_block < 2:
        raise ValueError("controller probe requires >=4 blocks and >=2 steps per block")
    effective = cfg.training.micro_batch_size * cfg.training.gradient_accumulation
    if effective != 24:
        raise ValueError("current preregistered controller probe requires effective batch 24")
    manifest = json.loads((Path(cfg.data.prepared_dir) / "manifest.json").read_text("utf-8"))
    actions = {"micro24_accum1": (24, 1), "micro12_accum2": (12, 2)}
    static = _run_policy(
        cfg, manifest, actions=actions, blocks=blocks, steps_per_block=steps_per_block,
        controlled=False,
    )
    controlled = _run_policy(
        cfg, manifest, actions=actions, blocks=blocks, steps_per_block=steps_per_block,
        controlled=True,
    )
    report = {
        "schema_version": 1,
        "benchmark": "molt-loss-conditioned-time-energy-controller-kill-test",
        "created_utc": datetime.now(UTC).isoformat(),
        "config": cfg.to_dict(),
        "blocks": blocks,
        "steps_per_block": steps_per_block,
        "static": static,
        "controller": controlled,
        "time_change_fraction": controlled["total_seconds"] / static["total_seconds"] - 1,
        "energy_change_fraction": controlled["total_gpu_board_energy_joules"]
        / static["total_gpu_board_energy_joules"] - 1,
        "interpretation_limit": (
            "Training-loss progress is a noisy kill-test signal. Promotion requires multiple "
            "full runs measured to the immutable validation-NLL target."
        ),
    }
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    path = root / f"controller-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    atomic_json(path, report)
    report["artifact_path"] = str(path)
    return report
