from __future__ import annotations

import json
import os
import platform
import sys
import time
import uuid
from pathlib import Path
from typing import Any

import torch

from ai_local.core.config import ExperimentConfig
from ai_local.core.io import atomic_json
from ai_local.core.io import sha256_file


class RunStore:
    def __init__(self, cfg: ExperimentConfig, existing: str | Path | None = None):
        if existing is None:
            stamp = time.strftime("%Y%m%d-%H%M%S")
            safe_name = "".join(ch if ch.isalnum() or ch in "-_" else "-" for ch in cfg.run_name)
            self.path = Path(cfg.artifacts_dir) / f"{stamp}-{safe_name}-{uuid.uuid4().hex[:8]}"
            self.path.mkdir(parents=True, exist_ok=False)
            atomic_json(self.path / "spec.resolved.json", cfg.to_dict())
        else:
            self.path = Path(existing)
            if not self.path.is_dir():
                raise FileNotFoundError(self.path)
        self.events_path = self.path / "events.jsonl"

    def environment(self) -> None:
        value: dict[str, Any] = {
            "python": sys.version,
            "platform": platform.platform(),
            "torch": torch.__version__,
            "cuda_available": torch.cuda.is_available(),
            "torch_cuda": torch.version.cuda,
        }
        if torch.cuda.is_available():
            value["gpu"] = torch.cuda.get_device_name(0)
            value["gpu_capability"] = torch.cuda.get_device_capability(0)
        atomic_json(self.path / "environment.json", value)

    def event(self, kind: str, **fields: Any) -> None:
        record = {"time_unix": time.time(), "time_monotonic": time.perf_counter(), "kind": kind, **fields}
        with self.events_path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(record, sort_keys=True) + "\n")

    def status(self, state: str, **fields: Any) -> None:
        atomic_json(self.path / "status.json", {"state": state, "updated_unix": time.time(), **fields})

    def checkpoint_path(self) -> Path:
        return self.path / "checkpoint.pt"

    def checkpoint_metadata_path(self) -> Path:
        return self.path / "checkpoint.complete.json"

    def save_checkpoint(self, state: dict[str, Any]) -> Path:
        target = self.checkpoint_path()
        metadata = self.checkpoint_metadata_path()
        previous = self.path / "checkpoint.previous.pt"
        previous_metadata = self.path / "checkpoint.previous.complete.json"
        temporary = target.with_suffix(".pt.tmp")
        torch.save(state, temporary)
        with temporary.open("r+b") as handle:
            handle.flush()
            os.fsync(handle.fileno())
        digest = sha256_file(temporary)
        size = temporary.stat().st_size
        if target.exists():
            os.replace(target, previous)
            if metadata.exists():
                os.replace(metadata, previous_metadata)
        os.replace(temporary, target)
        atomic_json(metadata, {"schema_version": 1, "sha256": digest, "bytes": size})
        return target

    def summary(self, value: dict[str, Any]) -> None:
        atomic_json(self.path / "metrics.summary.json", value)


def resolve_run(value: str | Path, artifacts_root: str | Path = "artifacts/runs") -> Path:
    direct = Path(value)
    if direct.is_dir():
        return direct
    candidate = Path(artifacts_root) / str(value)
    if candidate.is_dir():
        return candidate
    raise FileNotFoundError(f"run not found: {value}")


def _valid_checkpoint(checkpoint: Path, metadata: Path) -> bool:
    if not checkpoint.is_file() or not metadata.is_file():
        return False
    try:
        record = json.loads(metadata.read_text(encoding="utf-8"))
        return checkpoint.stat().st_size == record["bytes"] and sha256_file(checkpoint) == record["sha256"]
    except (OSError, ValueError, KeyError, json.JSONDecodeError):
        return False


def resolve_checkpoint(run: str | Path) -> Path:
    root = Path(run)
    primary = root / "checkpoint.pt"
    if _valid_checkpoint(primary, root / "checkpoint.complete.json"):
        return primary
    previous = root / "checkpoint.previous.pt"
    if _valid_checkpoint(previous, root / "checkpoint.previous.complete.json"):
        return previous
    raise ValueError(f"no valid checkpoint with matching completion metadata in {root}")
