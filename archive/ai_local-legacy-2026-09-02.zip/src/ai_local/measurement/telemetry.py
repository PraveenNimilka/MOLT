from __future__ import annotations

import threading
import time
from dataclasses import asdict, dataclass

import psutil


@dataclass(frozen=True)
class Sample:
    monotonic_seconds: float
    process_rss_bytes: int
    system_available_bytes: int
    cpu_percent: float
    gpu_power_watts: float | None = None
    gpu_used_bytes: int | None = None
    gpu_utilization_percent: float | None = None
    gpu_temperature_c: float | None = None
    gpu_graphics_clock_mhz: float | None = None
    gpu_memory_clock_mhz: float | None = None
    gpu_performance_state: int | None = None
    gpu_enforced_power_limit_watts: float | None = None
    gpu_clock_throttle_reasons: int | None = None


class Telemetry:
    def __init__(self, interval_seconds: float, enable_gpu: bool):
        self.interval = interval_seconds
        self.enable_gpu = enable_gpu
        self.samples: list[Sample] = []
        self.errors: list[str] = []
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._nvml = None
        self._handle = None

    def start(self) -> None:
        if self.enable_gpu:
            try:
                import pynvml

                pynvml.nvmlInit()
                self._nvml = pynvml
                self._handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            except Exception as exc:  # telemetry failure is recorded, never hidden
                self.errors.append(f"NVML unavailable: {type(exc).__name__}: {exc}")
        self._thread = threading.Thread(target=self._run, name="ai-local-telemetry", daemon=True)
        self._thread.start()

    def _run(self) -> None:
        process = psutil.Process()
        process.cpu_percent(None)
        while not self._stop.is_set():
            now = time.perf_counter()
            power = used = utilization = temperature = graphics_clock = memory_clock = pstate = None
            enforced_limit = throttle_reasons = None
            if self._nvml is not None and self._handle is not None:
                try:
                    power = self._nvml.nvmlDeviceGetPowerUsage(self._handle) / 1000.0
                    used = int(self._nvml.nvmlDeviceGetMemoryInfo(self._handle).used)
                    utilization = float(self._nvml.nvmlDeviceGetUtilizationRates(self._handle).gpu)
                    temperature = float(
                        self._nvml.nvmlDeviceGetTemperature(
                            self._handle, self._nvml.NVML_TEMPERATURE_GPU
                        )
                    )
                    graphics_clock = float(
                        self._nvml.nvmlDeviceGetClockInfo(
                            self._handle, self._nvml.NVML_CLOCK_GRAPHICS
                        )
                    )
                    memory_clock = float(
                        self._nvml.nvmlDeviceGetClockInfo(
                            self._handle, self._nvml.NVML_CLOCK_MEM
                        )
                    )
                    pstate = int(self._nvml.nvmlDeviceGetPerformanceState(self._handle))
                    enforced_limit = float(
                        self._nvml.nvmlDeviceGetEnforcedPowerLimit(self._handle)
                    ) / 1000.0
                    throttle_reasons = int(
                        self._nvml.nvmlDeviceGetCurrentClocksThrottleReasons(self._handle)
                    )
                except Exception as exc:
                    self.errors.append(f"NVML sample failed: {type(exc).__name__}: {exc}")
            memory = psutil.virtual_memory()
            self.samples.append(
                Sample(
                    monotonic_seconds=now,
                    process_rss_bytes=process.memory_info().rss,
                    system_available_bytes=memory.available,
                    cpu_percent=process.cpu_percent(None),
                    gpu_power_watts=power,
                    gpu_used_bytes=used,
                    gpu_utilization_percent=utilization,
                    gpu_temperature_c=temperature,
                    gpu_graphics_clock_mhz=graphics_clock,
                    gpu_memory_clock_mhz=memory_clock,
                    gpu_performance_state=pstate,
                    gpu_enforced_power_limit_watts=enforced_limit,
                    gpu_clock_throttle_reasons=throttle_reasons,
                )
            )
            self._stop.wait(self.interval)

    def stop(self) -> dict[str, object]:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=max(2.0, self.interval * 3))
        if self._nvml is not None:
            try:
                self._nvml.nvmlShutdown()
            except Exception as exc:
                self.errors.append(f"NVML shutdown failed: {type(exc).__name__}: {exc}")
        return self.summary()

    def summary(self) -> dict[str, object]:
        energy = integrate_gpu_energy(self.samples)
        return {
            "sample_count": len(self.samples),
            "interval_seconds": self.interval,
            "peak_process_rss_bytes": max((s.process_rss_bytes for s in self.samples), default=None),
            "minimum_system_available_bytes": min((s.system_available_bytes for s in self.samples), default=None),
            "peak_gpu_used_bytes": max((s.gpu_used_bytes for s in self.samples if s.gpu_used_bytes is not None), default=None),
            "peak_gpu_temperature_c": max(
                (s.gpu_temperature_c for s in self.samples if s.gpu_temperature_c is not None),
                default=None,
            ),
            "minimum_gpu_graphics_clock_mhz": min(
                (
                    s.gpu_graphics_clock_mhz
                    for s in self.samples
                    if s.gpu_graphics_clock_mhz is not None
                ),
                default=None,
            ),
            "maximum_gpu_graphics_clock_mhz": max(
                (
                    s.gpu_graphics_clock_mhz
                    for s in self.samples
                    if s.gpu_graphics_clock_mhz is not None
                ),
                default=None,
            ),
            "minimum_gpu_enforced_power_limit_watts": min(
                (
                    s.gpu_enforced_power_limit_watts
                    for s in self.samples
                    if s.gpu_enforced_power_limit_watts is not None
                ),
                default=None,
            ),
            "maximum_gpu_enforced_power_limit_watts": max(
                (
                    s.gpu_enforced_power_limit_watts
                    for s in self.samples
                    if s.gpu_enforced_power_limit_watts is not None
                ),
                default=None,
            ),
            "gpu_board_energy_joules": energy,
            "errors": self.errors,
            "samples": [asdict(sample) for sample in self.samples],
        }


def integrate_gpu_energy(samples: list[Sample]) -> float | None:
    powered = [sample for sample in samples if sample.gpu_power_watts is not None]
    if len(powered) < 2:
        return None
    energy = 0.0
    for left, right in zip(powered, powered[1:]):
        dt = right.monotonic_seconds - left.monotonic_seconds
        if dt < 0:
            raise ValueError("telemetry timestamps are not monotonic")
        energy += dt * (float(left.gpu_power_watts) + float(right.gpu_power_watts)) / 2.0
    return energy
