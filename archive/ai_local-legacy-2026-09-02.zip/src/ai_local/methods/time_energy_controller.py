from __future__ import annotations

import math
from dataclasses import dataclass, field


@dataclass(frozen=True)
class ControllerObservation:
    action: str
    seconds: float
    joules: float
    tokens: int
    loss_before: float
    loss_after: float
    peak_allocated_bytes: int
    total_vram_bytes: int
    gpu_utilization_percent: float | None = None
    enforced_power_limit_watts: float | None = None


@dataclass
class ActionEstimate:
    observations: list[ControllerObservation] = field(default_factory=list)

    def add(self, observation: ControllerObservation) -> None:
        if observation.seconds <= 0 or observation.joules <= 0 or observation.tokens <= 0:
            raise ValueError("controller observations require positive cost and tokens")
        self.observations.append(observation)

    @property
    def count(self) -> int:
        return len(self.observations)

    def mean(self, field_name: str) -> float:
        return sum(float(getattr(item, field_name)) for item in self.observations) / self.count

    def relative_uncertainty(self) -> float:
        """Conservative relative standard error shared by time and energy estimates."""
        if self.count < 2:
            return math.inf
        values = [item.seconds / item.tokens for item in self.observations]
        mean = sum(values) / self.count
        variance = sum((value - mean) ** 2 for value in values) / (self.count - 1)
        return math.sqrt(variance / self.count) / mean if mean else math.inf


class LossConditionedTimeEnergyController:
    """Experimental conservative controller; never silently changes workload semantics.

    It estimates remaining time and energy to a validation-loss target from live loss
    progress, then changes action only when the candidate's uncertainty-adjusted
    prediction improves *both* objectives by the configured promotion margin.
    """

    def __init__(
        self,
        actions: list[str],
        *,
        target_loss: float,
        minimum_improvement: float = 0.01,
        exploration_blocks: int = 2,
        minimum_vram_headroom_bytes: int = 256 * 1024 * 1024,
    ) -> None:
        if not actions or len(set(actions)) != len(actions):
            raise ValueError("actions must be a non-empty unique list")
        if target_loss <= 0 or not 0 < minimum_improvement < 1 or exploration_blocks < 1:
            raise ValueError("invalid controller settings")
        self.actions = actions
        self.target_loss = target_loss
        self.minimum_improvement = minimum_improvement
        self.exploration_blocks = exploration_blocks
        self.minimum_vram_headroom_bytes = minimum_vram_headroom_bytes
        self.estimates = {action: ActionEstimate() for action in actions}
        self.decisions: list[dict[str, object]] = []

    def observe(self, observation: ControllerObservation) -> None:
        if observation.action not in self.estimates:
            raise ValueError(f"unknown action: {observation.action}")
        self.estimates[observation.action].add(observation)

    def _project(self, action: str, current_loss: float) -> tuple[float, float, float]:
        estimate = self.estimates[action]
        progress = [max(0.0, item.loss_before - item.loss_after) for item in estimate.observations]
        mean_progress = sum(progress) / len(progress)
        if mean_progress <= 0:
            return math.inf, math.inf, math.inf
        blocks = max(0.0, current_loss - self.target_loss) / mean_progress
        seconds = blocks * estimate.mean("seconds")
        joules = blocks * estimate.mean("joules")
        return seconds, joules, estimate.relative_uncertainty()

    def choose(self, *, current_action: str, current_loss: float) -> str:
        for action in self.actions:
            if self.estimates[action].count < self.exploration_blocks:
                chosen = action
                break
        else:
            chosen = current_action
            current_time, current_energy, _ = self._project(current_action, current_loss)
            for action in self.actions:
                if action == current_action:
                    continue
                estimate = self.estimates[action]
                latest = estimate.observations[-1]
                headroom = latest.total_vram_bytes - latest.peak_allocated_bytes
                if headroom < self.minimum_vram_headroom_bytes:
                    continue
                candidate_time, candidate_energy, uncertainty = self._project(action, current_loss)
                penalty = 1.0 + min(0.25, uncertainty if math.isfinite(uncertainty) else 0.25)
                required = 1.0 - self.minimum_improvement
                if (
                    candidate_time * penalty <= current_time * required
                    and candidate_energy * penalty <= current_energy * required
                ):
                    chosen = action
                    current_time, current_energy = candidate_time, candidate_energy
        projections = {
            action: self._project(action, current_loss)[:2]
            for action in self.actions
            if self.estimates[action].count
        }
        self.decisions.append(
            {
                "current_action": current_action,
                "chosen_action": chosen,
                "current_loss": current_loss,
                "projections": projections,
            }
        )
        return chosen
