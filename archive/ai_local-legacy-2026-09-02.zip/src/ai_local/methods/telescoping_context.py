from __future__ import annotations

from dataclasses import dataclass
import itertools
from typing import Protocol

import torch
import torch.nn.functional as F


class ContextModel(Protocol):
    def __call__(
        self,
        tokens: torch.Tensor,
        targets: torch.Tensor | None = None,
        *,
        position_offset: int = 0,
    ) -> tuple[torch.Tensor, torch.Tensor | None]: ...


@dataclass(frozen=True)
class TelescopingSample:
    """One randomized estimator draw and its observable execution plan."""

    loss: torch.Tensor
    sampled_corrections: tuple[bool, ...]
    level_coefficients: tuple[float, ...]
    evaluated_contexts: tuple[int, ...]
    supervised_tokens: int


def validate_telescoping_spec(
    levels: tuple[int, ...], probabilities: tuple[float, ...], target_tokens: int
) -> None:
    if len(levels) < 2:
        raise ValueError("telescoping context requires at least two levels")
    if any(a >= b for a, b in zip(levels, levels[1:])):
        raise ValueError("context levels must be strictly increasing")
    if len(probabilities) != len(levels) - 1:
        raise ValueError("one correction probability is required per level transition")
    if any(not 0.0 < value <= 1.0 for value in probabilities):
        raise ValueError("correction probabilities must be in (0, 1]")
    if not 0 < target_tokens <= levels[0]:
        raise ValueError("target_tokens must be positive and no larger than the shortest context")


def coupled_suffix_loss(
    model: ContextModel,
    tokens: torch.Tensor,
    targets: torch.Tensor,
    *,
    context_length: int,
    full_context_length: int,
    target_tokens: int,
) -> torch.Tensor:
    """Loss for identical suffix targets under a nested causal context.

    Shorter contexts retain their absolute positions from the full window. This
    isolates available left context instead of also changing positional inputs.
    """

    if tokens.shape != targets.shape or tokens.ndim != 2:
        raise ValueError("tokens and targets must have identical [batch, length] shapes")
    if tokens.shape[1] != full_context_length:
        raise ValueError("input length must equal full_context_length")
    if not target_tokens <= context_length <= full_context_length:
        raise ValueError("expected target_tokens <= context_length <= full_context_length")
    position_offset = full_context_length - context_length
    logits, _ = model(
        tokens[:, -context_length:],
        position_offset=position_offset,
    )
    suffix_logits = logits[:, -target_tokens:, :].float()
    suffix_targets = targets[:, -target_tokens:]
    return F.cross_entropy(
        suffix_logits.reshape(-1, suffix_logits.shape[-1]),
        suffix_targets.reshape(-1),
    )


def correction_coefficients(
    probabilities: tuple[float, ...], sampled: tuple[bool, ...]
) -> tuple[float, ...]:
    if len(probabilities) != len(sampled):
        raise ValueError("sample mask length differs from probabilities")
    coefficients = [1.0] + [0.0] * len(probabilities)
    for index, (probability, include) in enumerate(zip(probabilities, sampled), start=1):
        if include:
            weight = 1.0 / probability
            coefficients[index] += weight
            coefficients[index - 1] -= weight
    return tuple(coefficients)


def analytic_probability_frontier(
    level_costs: tuple[float, ...],
    delta_norm_sq_ratios: tuple[float, ...],
    *,
    probability_grid: tuple[float, ...] = tuple(index / 20 for index in range(1, 21)),
) -> list[dict[str, object]]:
    """Rank Bernoulli schedules by an unbiased-SGD cost/variance proxy.

    For independent correction indicators, E||g_hat||^2 / ||g||^2 is
    1 + sum((1/p_k - 1)||delta_k||^2/||g||^2). Expected execution cost is
    calculated exactly by enumerating masks and their combined coefficients.
    """

    if len(level_costs) < 2 or len(delta_norm_sq_ratios) != len(level_costs) - 1:
        raise ValueError("costs and gradient deltas have incompatible lengths")
    if min(level_costs) <= 0 or min(delta_norm_sq_ratios) < 0:
        raise ValueError("costs must be positive and delta ratios non-negative")
    frontier: list[dict[str, object]] = []
    for probabilities in itertools.product(probability_grid, repeat=len(delta_norm_sq_ratios)):
        second_moment = 1.0 + sum(
            (1.0 / probability - 1.0) * ratio
            for probability, ratio in zip(probabilities, delta_norm_sq_ratios)
        )
        expected_cost = 0.0
        for sampled in itertools.product((False, True), repeat=len(probabilities)):
            mask_probability = 1.0
            for include, probability in zip(sampled, probabilities):
                mask_probability *= probability if include else 1.0 - probability
            coefficients = correction_coefficients(probabilities, sampled)
            plan_cost = sum(cost for cost, coefficient in zip(level_costs, coefficients) if coefficient != 0)
            expected_cost += mask_probability * plan_cost
        raw_speedup = level_costs[-1] / expected_cost
        frontier.append(
            {
                "probabilities": list(probabilities),
                "expected_cost_seconds": expected_cost,
                "raw_speedup": raw_speedup,
                "gradient_second_moment_ratio": second_moment,
                "variance_adjusted_speedup_proxy": raw_speedup / second_moment,
            }
        )
    return sorted(frontier, key=lambda item: float(item["variance_adjusted_speedup_proxy"]), reverse=True)


def draw_corrections(
    probabilities: tuple[float, ...], generator: torch.Generator
) -> tuple[bool, ...]:
    draws = torch.rand(len(probabilities), generator=generator, device="cpu")
    return tuple(bool(draw < probability) for draw, probability in zip(draws, probabilities))


def telescoping_context_loss(
    model: ContextModel,
    tokens: torch.Tensor,
    targets: torch.Tensor,
    *,
    levels: tuple[int, ...],
    probabilities: tuple[float, ...],
    target_tokens: int,
    generator: torch.Generator,
    sampled_corrections: tuple[bool, ...] | None = None,
) -> TelescopingSample:
    """Return an unbiased randomized estimator of the longest-context loss.

    E[J_l0 + sum I_k/p_k (J_lk - J_l(k-1))] = J_lK. Coefficients
    are combined before evaluation so a context is never forwarded twice.
    """

    validate_telescoping_spec(levels, probabilities, target_tokens)
    if tokens.shape[1] != levels[-1]:
        raise ValueError("batch length must equal the longest context level")
    sampled = sampled_corrections or draw_corrections(probabilities, generator)
    coefficients = correction_coefficients(probabilities, sampled)
    combined: torch.Tensor | None = None
    evaluated: list[int] = []
    for context, coefficient in zip(levels, coefficients):
        if coefficient == 0.0:
            continue
        value = coupled_suffix_loss(
            model,
            tokens,
            targets,
            context_length=context,
            full_context_length=levels[-1],
            target_tokens=target_tokens,
        )
        term = value * coefficient
        combined = term if combined is None else combined + term
        evaluated.append(context)
    assert combined is not None
    return TelescopingSample(
        loss=combined,
        sampled_corrections=sampled,
        level_coefficients=coefficients,
        evaluated_contexts=tuple(evaluated),
        supervised_tokens=tokens.shape[0] * target_tokens,
    )
