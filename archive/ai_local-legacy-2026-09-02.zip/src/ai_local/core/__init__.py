"""Stable domain types and validation."""
