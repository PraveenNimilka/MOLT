from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


class ConfigError(ValueError):
    """Raised when an experiment specification is invalid."""


@dataclass(frozen=True)
class DataConfig:
    kind: str = "synthetic"
    prepared_dir: str = "data/prepared/default"
    source: str | None = None
    train_bytes: int = 1_000_000
    validation_bytes: int = 100_000
    context_length: int = 64
    vocab_size: int = 256
    sampling: str = "random"
    tokenizer_path: str | None = None
    packing: str = "indexed"


@dataclass(frozen=True)
class ModelConfig:
    n_layers: int = 2
    d_model: int = 128
    n_heads: int = 4
    mlp_ratio: int = 4
    activation_checkpointing: bool = False
    activation_dtype: str = "parameter"
    parameter_dtype: str = "float32"
    max_context_length: int | None = None
    attention_backend: str = "auto"


@dataclass(frozen=True)
class TrainingConfig:
    device: str = "cpu"
    precision: str = "float32"
    optimizer: str = "adamw"
    learning_rate: float = 6e-4
    weight_decay: float = 0.1
    micro_batch_size: int = 4
    gradient_accumulation: int = 1
    max_steps: int = 10
    max_seconds: float | None = None
    eval_interval: int = 5
    eval_batches: int = 4
    checkpoint_interval: int = 5
    save_final_checkpoint: bool = True
    gradient_clip: float = 1.0
    warmup_steps: int = 0
    min_learning_rate_ratio: float = 1.0
    initialize_from_run: str | None = None
    fused_optimizer: bool = False


@dataclass(frozen=True)
class ExperimentConfig:
    schema_version: int = 1
    run_name: str = "experiment"
    seed: int = 1337
    artifacts_dir: str = "artifacts/runs"
    telemetry_interval_seconds: float = 0.2
    data: DataConfig = field(default_factory=DataConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "ExperimentConfig":
        known = {f.name for f in cls.__dataclass_fields__.values()}
        extra = set(raw) - known
        if extra:
            raise ConfigError(f"unknown top-level fields: {sorted(extra)}")
        try:
            cfg = cls(
                **{k: v for k, v in raw.items() if k not in {"data", "model", "training"}},
                data=DataConfig(**raw.get("data", {})),
                model=ModelConfig(**raw.get("model", {})),
                training=TrainingConfig(**raw.get("training", {})),
            )
        except TypeError as exc:
            raise ConfigError(str(exc)) from exc
        cfg.validate()
        return cfg

    @classmethod
    def load(cls, path: str | Path) -> "ExperimentConfig":
        with Path(path).open("r", encoding="utf-8") as handle:
            raw = json.load(handle)
        if not isinstance(raw, dict):
            raise ConfigError("configuration root must be an object")
        return cls.from_dict(raw)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def validate(self) -> None:
        if self.schema_version != 1:
            raise ConfigError(f"unsupported schema_version {self.schema_version}")
        if self.data.kind not in {"synthetic", "file", "text_bpe", "text_bpe_qa"}:
            raise ConfigError("data.kind must be synthetic, file, text_bpe, or text_bpe_qa")
        maximum_vocab = 65536 if self.data.kind.startswith("text_bpe") else 256
        if not 2 <= self.data.vocab_size <= maximum_vocab:
            raise ConfigError(f"vocabulary must be between 2 and {maximum_vocab}")
        if self.data.sampling not in {"random", "sequential"}:
            raise ConfigError("data.sampling must be random or sequential")
        if self.data.packing not in {"indexed", "contiguous"}:
            raise ConfigError("data.packing must be indexed or contiguous")
        if self.data.context_length < 2:
            raise ConfigError("context_length must be at least 2")
        if min(self.model.n_layers, self.model.d_model, self.model.n_heads) <= 0:
            raise ConfigError("model dimensions must be positive")
        if self.model.d_model % self.model.n_heads:
            raise ConfigError("d_model must be divisible by n_heads")
        if self.model.max_context_length is not None and self.model.max_context_length < self.data.context_length:
            raise ConfigError("model.max_context_length must cover data.context_length")
        if self.model.parameter_dtype not in {"float32", "bfloat16", "float16"}:
            raise ConfigError("unsupported parameter_dtype")
        if self.model.activation_dtype not in {"parameter", "bfloat16", "float16"}:
            raise ConfigError("activation_dtype must be parameter, bfloat16, or float16")
        if self.model.attention_backend not in {"auto", "flash", "efficient", "math"}:
            raise ConfigError("attention_backend must be auto, flash, efficient, or math")
        t = self.training
        if t.device not in {"cpu", "cuda"}:
            raise ConfigError("device must be cpu or cuda")
        if t.precision not in {"float32", "bfloat16", "float16"}:
            raise ConfigError("unsupported precision")
        if t.optimizer not in {"adamw", "sgd", "residual_sgd"}:
            raise ConfigError("optimizer must be adamw, sgd, or residual_sgd")
        if min(t.micro_batch_size, t.gradient_accumulation, t.max_steps) <= 0:
            raise ConfigError("batch, accumulation, and max_steps must be positive")
        if t.eval_batches <= 0 or t.eval_interval < 0 or t.checkpoint_interval < 0:
            raise ConfigError("evaluation/checkpoint values are invalid")
        if self.telemetry_interval_seconds <= 0:
            raise ConfigError("telemetry interval must be positive")
        if t.warmup_steps < 0 or t.warmup_steps > t.max_steps:
            raise ConfigError("warmup_steps must be between zero and max_steps")
        if not 0 <= t.min_learning_rate_ratio <= 1:
            raise ConfigError("min_learning_rate_ratio must be between zero and one")
