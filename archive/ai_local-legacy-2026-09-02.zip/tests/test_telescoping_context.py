from __future__ import annotations

import itertools

import torch

from ai_local.core.config import ExperimentConfig
from ai_local.methods.telescoping_context import (
    analytic_probability_frontier,
    correction_coefficients,
    coupled_suffix_loss,
    telescoping_context_loss,
    validate_telescoping_spec,
)
from ai_local.training.model import ByteTransformer


def _config() -> ExperimentConfig:
    raw = ExperimentConfig.load("configs/smoke-cpu.json").to_dict()
    raw["data"]["context_length"] = 8
    raw["data"]["vocab_size"] = 32
    raw["model"].update({"n_layers": 1, "d_model": 16, "n_heads": 2, "max_context_length": 8})
    return ExperimentConfig.from_dict(raw)


def _gradient(model: ByteTransformer, loss: torch.Tensor) -> torch.Tensor:
    model.zero_grad(set_to_none=True)
    loss.backward()
    return torch.cat([parameter.grad.reshape(-1) for parameter in model.parameters()])


def test_coefficients_telescope_when_all_corrections_are_sampled() -> None:
    assert correction_coefficients((1.0, 1.0), (True, True)) == (0.0, 0.0, 1.0)


def test_randomized_gradient_is_unbiased_by_exact_enumeration() -> None:
    torch.manual_seed(7)
    model = ByteTransformer(_config(), torch.device("cpu"))
    tokens = torch.randint(0, 32, (2, 8))
    targets = torch.randint(0, 32, (2, 8))
    reference_loss = coupled_suffix_loss(
        model, tokens, targets, context_length=8, full_context_length=8, target_tokens=2
    )
    reference_gradient = _gradient(model, reference_loss).clone()

    probabilities = (0.25, 0.5)
    expected_gradient = torch.zeros_like(reference_gradient)
    expected_loss = 0.0
    generator = torch.Generator().manual_seed(1)
    for sampled in itertools.product((False, True), repeat=2):
        probability = 1.0
        for include, rate in zip(sampled, probabilities):
            probability *= rate if include else 1.0 - rate
        estimate = telescoping_context_loss(
            model,
            tokens,
            targets,
            levels=(2, 4, 8),
            probabilities=probabilities,
            target_tokens=2,
            generator=generator,
            sampled_corrections=sampled,
        )
        expected_loss += probability * float(estimate.loss.detach())
        expected_gradient += probability * _gradient(model, estimate.loss)

    torch.testing.assert_close(torch.tensor(expected_loss), reference_loss.detach(), rtol=1e-5, atol=1e-6)
    torch.testing.assert_close(expected_gradient, reference_gradient, rtol=2e-5, atol=2e-6)


def test_short_context_preserves_absolute_suffix_positions() -> None:
    model = ByteTransformer(_config(), torch.device("cpu"))
    tokens = torch.randint(0, 32, (1, 8))
    full_logits, _ = model(tokens)
    short_logits, _ = model(tokens[:, -4:], position_offset=4)
    assert full_logits.shape == (1, 8, 32)
    assert short_logits.shape == (1, 4, 32)


def test_spec_rejects_invalid_probability() -> None:
    try:
        validate_telescoping_spec((2, 4), (0.0,), 2)
    except ValueError as exc:
        assert "probabilities" in str(exc)
    else:
        raise AssertionError("invalid probability was accepted")


def test_analytic_frontier_prefers_exact_gradient_when_deltas_are_large() -> None:
    frontier = analytic_probability_frontier(
        (1.0, 2.0),
        (10.0,),
        probability_grid=(0.5, 1.0),
    )
    assert frontier[0]["probabilities"] == [1.0]
    assert frontier[0]["gradient_second_moment_ratio"] == 1.0
