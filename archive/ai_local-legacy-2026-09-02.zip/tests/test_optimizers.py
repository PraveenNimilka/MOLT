import torch

from ai_local.core.config import ExperimentConfig
from ai_local.training.optimizers import ResidualSGD, build_optimizer


def test_residual_sgd_accumulates_sub_ulp_updates() -> None:
    direct = torch.tensor([1.0], dtype=torch.bfloat16, requires_grad=True)
    residual = torch.tensor([1.0], dtype=torch.bfloat16, requires_grad=True)
    direct_optimizer = torch.optim.SGD([direct], lr=0.001)
    residual_optimizer = ResidualSGD([residual], lr=0.001)
    for _ in range(16):
        direct.grad = torch.ones_like(direct)
        residual.grad = torch.ones_like(residual)
        direct_optimizer.step()
        residual_optimizer.step()
    assert float(direct.detach()) == 1.0
    assert float(residual.detach()) < 0.99


def test_residual_state_round_trips() -> None:
    value = torch.tensor([1.0], dtype=torch.bfloat16, requires_grad=True)
    optimizer = ResidualSGD([value], lr=0.001)
    value.grad = torch.ones_like(value)
    optimizer.step()
    state = optimizer.state_dict()
    restored = ResidualSGD([value], lr=0.001)
    restored.load_state_dict(state)
    assert "residual" in restored.state[value]


def test_adamw_state_is_fp32_for_fp32_master_parameters() -> None:
    model = torch.nn.Linear(4, 4)
    cfg = ExperimentConfig.from_dict(
        {"training": {"optimizer": "adamw", "learning_rate": 0.001}}
    )
    optimizer = build_optimizer(model, cfg)
    model(torch.ones(1, 4)).sum().backward()
    optimizer.step()
    tensor_states = [
        value
        for state in optimizer.state.values()
        for value in state.values()
        if isinstance(value, torch.Tensor) and value.numel() > 1
    ]
    assert tensor_states
    assert all(value.dtype == torch.float32 for value in tensor_states)
