from ai_local.evaluation.frontier import integrate_sample_field_until, interpolate_nll_crossing


def test_interpolates_validation_target() -> None:
    result = interpolate_nll_crossing(
        [
            {"validation_nll": 4.0, "elapsed_seconds": 10.0, "tokens": 100},
            {"validation_nll": 2.0, "elapsed_seconds": 30.0, "tokens": 300},
        ],
        3.0,
    )
    assert result == {"seconds": 20.0, "tokens": 200.0}


def test_integrates_power_with_interpolated_boundary() -> None:
    samples = [
        {"monotonic_seconds": 100.0, "gpu_power_watts": 10.0},
        {"monotonic_seconds": 102.0, "gpu_power_watts": 20.0},
        {"monotonic_seconds": 104.0, "gpu_power_watts": 20.0},
    ]
    # 0..2 seconds is a 10->20 W trapezoid (30 J); the next second is 20 J.
    assert integrate_sample_field_until(samples, 3.0, "gpu_power_watts") == 50.0
