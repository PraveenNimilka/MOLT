from ai_local.measurement.telemetry import Sample, integrate_gpu_energy


def test_trapezoid_energy_integration() -> None:
    samples = [
        Sample(0.0, 1, 1, 0.0, gpu_power_watts=10.0),
        Sample(2.0, 1, 1, 0.0, gpu_power_watts=20.0),
        Sample(3.0, 1, 1, 0.0, gpu_power_watts=20.0),
    ]
    assert integrate_gpu_energy(samples) == 50.0


def test_energy_unavailable_without_two_power_samples() -> None:
    assert integrate_gpu_energy([]) is None
    assert integrate_gpu_energy([Sample(0.0, 1, 1, 0.0)]) is None
