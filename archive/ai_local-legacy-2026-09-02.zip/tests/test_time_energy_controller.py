from ai_local.methods.time_energy_controller import (
    ControllerObservation,
    LossConditionedTimeEnergyController,
)


def observation(action: str, seconds: float, joules: float, progress: float):
    return ControllerObservation(
        action=action,
        seconds=seconds,
        joules=joules,
        tokens=100,
        loss_before=5.0,
        loss_after=5.0 - progress,
        peak_allocated_bytes=1_000,
        total_vram_bytes=1_000_000_000,
    )


def test_controller_explores_then_selects_joint_dominator():
    controller = LossConditionedTimeEnergyController(
        ["baseline", "candidate"], target_loss=3.0, exploration_blocks=2
    )
    assert controller.choose(current_action="baseline", current_loss=5.0) == "baseline"
    for _ in range(2):
        controller.observe(observation("baseline", 10.0, 100.0, 0.1))
    assert controller.choose(current_action="baseline", current_loss=4.8) == "candidate"
    for _ in range(2):
        controller.observe(observation("candidate", 7.0, 70.0, 0.1))
    assert controller.choose(current_action="baseline", current_loss=4.6) == "candidate"


def test_controller_rejects_time_energy_tradeoff():
    controller = LossConditionedTimeEnergyController(
        ["baseline", "tradeoff"], target_loss=3.0, exploration_blocks=2
    )
    for _ in range(2):
        controller.observe(observation("baseline", 10.0, 100.0, 0.1))
        controller.observe(observation("tradeoff", 8.0, 110.0, 0.1))
    assert controller.choose(current_action="baseline", current_loss=4.5) == "baseline"
