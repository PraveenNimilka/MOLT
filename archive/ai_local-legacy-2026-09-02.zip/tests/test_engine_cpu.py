import json
from pathlib import Path

import pytest

from ai_local.core.config import ExperimentConfig
from ai_local.data.bytes import prepare
from ai_local.training.engine import train
from ai_local.experiments.store import resolve_checkpoint
from ai_local.evaluation.runs import generate_run


def tiny_config(tmp_path: Path) -> ExperimentConfig:
    return ExperimentConfig.from_dict(
        {
            "run_name": "test-cpu",
            "artifacts_dir": str(tmp_path / "runs"),
            "telemetry_interval_seconds": 0.01,
            "data": {
                "prepared_dir": str(tmp_path / "data"),
                "train_bytes": 2048,
                "validation_bytes": 512,
                "context_length": 8,
            },
            "model": {"n_layers": 1, "d_model": 32, "n_heads": 4},
            "training": {
                "device": "cpu",
                "precision": "float32",
                "micro_batch_size": 2,
                "max_steps": 2,
                "eval_interval": 1,
                "eval_batches": 1,
                "checkpoint_interval": 1,
            },
        }
    )


def test_cpu_training_writes_complete_artifacts(tmp_path: Path) -> None:
    cfg = tiny_config(tmp_path)
    prepare(cfg)
    run = train(cfg)
    summary = json.loads((run / "metrics.summary.json").read_text())
    assert summary["state"] == "completed"
    assert summary["steps"] == 2
    assert summary["tokens"] == 32
    assert (run / "checkpoint.pt").is_file()
    assert (run / "checkpoint.complete.json").is_file()
    assert len(summary["evaluations"]) == 3
    with pytest.raises(ValueError, match="completed runs"):
        train(cfg, resume_run=run)


def test_corrupt_latest_checkpoint_falls_back_to_previous(tmp_path: Path) -> None:
    cfg = tiny_config(tmp_path)
    prepare(cfg)
    run = train(cfg)
    assert (run / "checkpoint.previous.pt").is_file()
    (run / "checkpoint.pt").write_bytes(b"corrupt")
    assert resolve_checkpoint(run).name == "checkpoint.previous.pt"


def test_corrupt_prepared_data_is_rejected(tmp_path: Path) -> None:
    cfg = tiny_config(tmp_path)
    manifest = prepare(cfg)
    Path(manifest["train"]["path"]).write_bytes(b"corrupt")
    with pytest.raises(ValueError, match="hash mismatch"):
        train(cfg)


def test_checkpoint_can_generate_deterministically(tmp_path: Path) -> None:
    cfg = tiny_config(tmp_path)
    prepare(cfg)
    run = train(cfg)
    first = generate_run(run, "Once", max_new_bytes=4, temperature=0.8, seed=9)
    second = generate_run(run, "Once", max_new_bytes=4, temperature=0.8, seed=9)
    assert first["completion_byte_ids"] == second["completion_byte_ids"]
    assert len(first["completion_byte_ids"]) == 4
