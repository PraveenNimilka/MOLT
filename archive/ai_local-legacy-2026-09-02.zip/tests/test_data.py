from pathlib import Path

import torch
from tokenizers import Tokenizer

from ai_local.core.config import ExperimentConfig
from ai_local.data.bytes import ByteBatcher, prepare


def test_synthetic_preparation_is_deterministic(tmp_path: Path) -> None:
    cfg = ExperimentConfig.from_dict(
        {
            "data": {
                "prepared_dir": str(tmp_path / "prepared"),
                "train_bytes": 1024,
                "validation_bytes": 256,
                "context_length": 8,
            }
        }
    )
    first = prepare(cfg)
    second = prepare(cfg)
    assert first == second
    assert first["train"]["bytes"] == 1024
    assert len(first["train"]["sha256"]) == 64


def test_byte_batcher_is_deterministic_and_targets_are_shifted(tmp_path: Path) -> None:
    source = tmp_path / "bytes.bin"
    source.write_bytes(bytes(range(64)))
    first = ByteBatcher(source, context_length=8, seed=7, device=torch.device("cpu"))
    second = ByteBatcher(source, context_length=8, seed=7, device=torch.device("cpu"))

    x1, y1 = first.batch(4)
    x2, y2 = second.batch(4)

    assert torch.equal(x1, x2)
    assert torch.equal(y1, y2)
    assert torch.equal(x1[:, 1:], y1[:, :-1])
    assert first.storage_backend == "mmap"
    assert first.source_path == source


def test_file_preparation_streams_exact_splits(tmp_path: Path) -> None:
    source = tmp_path / "source.bin"
    source.write_bytes(bytes(range(256)) * 8)
    cfg = ExperimentConfig.from_dict(
        {
            "data": {
                "kind": "file",
                "source": str(source),
                "prepared_dir": str(tmp_path / "prepared"),
                "train_bytes": 1000,
                "validation_bytes": 200,
                "context_length": 8,
            }
        }
    )

    manifest = prepare(cfg)

    assert Path(manifest["train"]["path"]).read_bytes() == source.read_bytes()[:1000]
    assert Path(manifest["validation"]["path"]).read_bytes() == source.read_bytes()[1000:1200]


def test_bpe_preparation_and_sequential_int32_batches(tmp_path: Path) -> None:
    source = tmp_path / "stories.txt"
    source.write_text(
        ("Once upon a time, a fox found a red kite.\n<|endoftext|>\n" * 100),
        encoding="utf-8",
    )
    cfg = ExperimentConfig.from_dict(
        {
            "data": {
                "kind": "text_bpe",
                "source": str(source),
                "prepared_dir": str(tmp_path / "bpe"),
                "train_bytes": 4500,
                "validation_bytes": 500,
                "context_length": 8,
                "vocab_size": 300,
                "sampling": "sequential",
            }
        }
    )

    manifest = prepare(cfg)
    tokenizer = Tokenizer.from_file(manifest["tokenizer"]["path"])
    batcher = ByteBatcher(
        manifest["train"]["path"],
        8,
        7,
        torch.device("cpu"),
        storage_dtype="int32",
        sampling="sequential",
    )
    x, y = batcher.batch(3)

    assert manifest["storage_dtype"] == "int32"
    assert 256 < tokenizer.get_vocab_size() <= 300
    assert int(x.max()) < 300
    assert torch.equal(x[:, 1:], y[:, :-1])
    assert batcher.sequential_cursor == 24


def test_qa_loss_mask_ignores_prompt_tokens(tmp_path: Path) -> None:
    source = tmp_path / "qa.txt"
    source.write_text(
        (
            "<|question|>What color is the kite?<|answer|>The kite is red.<|endoftext|>\n"
            * 40
        ),
        encoding="utf-8",
    )
    cfg = ExperimentConfig.from_dict(
        {
            "data": {
                "kind": "text_bpe_qa",
                "source": str(source),
                "prepared_dir": str(tmp_path / "qa"),
                "train_bytes": 2500,
                "validation_bytes": 500,
                "context_length": 8,
                "vocab_size": 280,
                "sampling": "sequential",
            }
        }
    )
    manifest = prepare(cfg)
    batcher = ByteBatcher(
        manifest["train"]["path"],
        8,
        1,
        torch.device("cpu"),
        storage_dtype="int32",
        sampling="sequential",
        loss_mask_path=manifest["train"]["loss_mask_path"],
    )
    _, targets = batcher.batch(8)
    assert (targets == -100).any()
    assert (targets != -100).any()


def test_contiguous_packing_is_tensor_identical_to_indexed(tmp_path: Path) -> None:
    source = tmp_path / "tokens.bin"
    source.write_bytes(bytes(range(128)))
    indexed = ByteBatcher(
        source,
        context_length=8,
        seed=3,
        device=torch.device("cpu"),
        sampling="sequential",
        packing="indexed",
    )
    contiguous = ByteBatcher(
        source,
        context_length=8,
        seed=3,
        device=torch.device("cpu"),
        sampling="sequential",
        packing="contiguous",
    )
    for _ in range(3):
        indexed_batch = indexed.batch(4)
        contiguous_batch = contiguous.batch(4)
        assert all(torch.equal(left, right) for left, right in zip(indexed_batch, contiguous_batch))
