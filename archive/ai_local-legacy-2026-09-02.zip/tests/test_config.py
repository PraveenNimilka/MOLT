import pytest

from ai_local.core.config import ConfigError, ExperimentConfig


def test_rejects_unknown_top_level_field() -> None:
    with pytest.raises(ConfigError, match="unknown"):
        ExperimentConfig.from_dict({"mystery": True})


def test_rejects_invalid_head_width() -> None:
    with pytest.raises(ConfigError, match="divisible"):
        ExperimentConfig.from_dict({"model": {"d_model": 63, "n_heads": 4}})


def test_one_billion_config_is_explicit_and_valid() -> None:
    cfg = ExperimentConfig.load("configs/one-billion-mechanism.json")
    assert cfg.model.parameter_dtype == "bfloat16"
    assert cfg.training.optimizer == "sgd"
    assert cfg.training.save_final_checkpoint is False
