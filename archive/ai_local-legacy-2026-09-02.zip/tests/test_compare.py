import json
from pathlib import Path

from ai_local.evaluation.runs import compare_runs


def _run(root: Path, name: str, evaluations: list[dict[str, float]]) -> Path:
    path = root / name
    path.mkdir()
    (path / "metrics.summary.json").write_text(
        json.dumps(
            {
                "model": {"total_parameters": 10},
                "total_seconds": evaluations[-1]["elapsed_seconds"],
                "tokens_per_second_end_to_end": 1.0,
                "evaluations": evaluations,
            }
        )
    )
    return path


def test_compare_interpolates_first_quality_crossing(tmp_path: Path) -> None:
    baseline = _run(
        tmp_path,
        "baseline",
        [
            {"elapsed_seconds": 0.0, "tokens": 0, "validation_bits_per_byte": 8.0},
            {"elapsed_seconds": 10.0, "tokens": 100, "validation_bits_per_byte": 6.0},
        ],
    )
    candidate = _run(
        tmp_path,
        "candidate",
        [
            {"elapsed_seconds": 0.0, "tokens": 0, "validation_bits_per_byte": 8.0},
            {"elapsed_seconds": 4.0, "tokens": 40, "validation_bits_per_byte": 7.0},
            {"elapsed_seconds": 8.0, "tokens": 80, "validation_bits_per_byte": 5.0},
        ],
    )
    result = compare_runs(baseline, candidate)
    assert result["time_to_target"]["candidate"] == {"seconds": 6.0, "tokens": 60.0}
    assert result["time_to_target_speedup"] == 10.0 / 6.0
