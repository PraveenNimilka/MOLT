import torch

from ai_local.core.config import ExperimentConfig
from ai_local.training.model import ByteTransformer, model_stats


def test_baseline_parameter_count() -> None:
    cfg = ExperimentConfig.load("configs/baseline.json")
    model = ByteTransformer(cfg, torch.device("meta"))
    assert model_stats(model).total_parameters == 6_449_664


def test_one_billion_parameter_count() -> None:
    cfg = ExperimentConfig.load("configs/one-billion-mechanism.json")
    model = ByteTransformer(cfg, torch.device("meta"))
    stats = model_stats(model)
    assert stats.total_parameters == 1_007_710_208
    assert stats.parameter_bytes == 2_015_420_416


def test_molt_ai_50m_parameter_and_master_weight_precision() -> None:
    cfg = ExperimentConfig.load("configs/molt-ai-50m-pretrain.json")
    model = ByteTransformer(cfg, torch.device("meta"))
    stats = model_stats(model)
    assert stats.total_parameters == 49_883_520
    assert stats.parameter_bytes == 199_534_080
    qa_cfg = ExperimentConfig.load("configs/molt-ai-50m-qa.json")
    qa_model = ByteTransformer(qa_cfg, torch.device("meta"))
    assert model_stats(qa_model) == stats


def test_activation_dtype_does_not_change_parameters() -> None:
    raw = ExperimentConfig.load("configs/molt-ai-50m-pretrain.json").to_dict()
    raw["model"]["activation_dtype"] = "bfloat16"
    cfg = ExperimentConfig.from_dict(raw)
    model = ByteTransformer(cfg, torch.device("meta"))
    assert model.activation_dtype == torch.bfloat16
    assert model_stats(model).total_parameters == 49_883_520
